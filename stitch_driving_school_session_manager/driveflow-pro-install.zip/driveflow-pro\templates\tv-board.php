<?php
defined('ABSPATH') || exit;

/**
 * DriveFlow Pro - Smart Lobby TV & Monitor Display
 * High-definition, executive digital dashboard for driving school waiting lobbies and offices.
 */
?>
<div class="driveflow-app driveflow-tv" dir="ltr" data-driveflow-board>
    <!-- TV Header -->
    <header class="driveflow-tv-header">
        <div class="driveflow-brand">
            <?php if (!empty($brand['logo'])) : ?>
                <img src="<?php echo esc_url($brand['logo']); ?>" alt="<?php echo esc_attr($brand['name']); ?> logo" class="df-tv-logo-img">
            <?php else : ?>
                <div class="df-tv-logo-placeholder">🚗</div>
            <?php endif; ?>
            <div>
                <strong class="df-tv-school-title"><?php echo esc_html($brand['name']); ?></strong>
                <span class="df-tv-sub">Smart Lobby TV & Live Dispatch Terminal</span>
            </div>
        </div>

        <div class="driveflow-tv-center">
            <div class="df-live-pill">
                <span class="df-pulsing-dot"></span> LIVE LOBBY BOARD
            </div>
        </div>

        <div class="driveflow-tv-right">
            <div class="df-board-time-box">
                <time data-board-clock class="df-clock-time">--:--:--</time>
                <div data-board-date class="df-clock-date"><?php echo esc_html(date_i18n('l, F j, Y')); ?></div>
            </div>
            <div class="df-tv-controls">
                <button type="button" class="df-icon-btn" data-toggle-speech title="Toggle Voice Announcer (Speaks student & instructor names)">
                    🗣️
                </button>
                <button type="button" class="df-icon-btn is-active" data-toggle-sound title="Toggle Chime Alert Sound">
                    🔔
                </button>
                <button type="button" class="df-icon-btn" data-toggle-fullscreen title="Toggle Fullscreen Mode">
                    ⛶
                </button>
            </div>
        </div>
    </header>

    <!-- Main Sessions Board -->
    <main class="driveflow-board-content">
        <div class="driveflow-board-heading">
            <div style="display:flex;align-items:center;gap:12px;">
                <h2 style="font-size:22px;font-weight:800;color:#ffffff;margin:0;letter-spacing:-0.5px;">Today's Behind-The-Wheel Schedule</h2>
                <span class="df-tv-live-tag">REAL-TIME</span>
            </div>
            <div class="df-board-legend">
                <span class="legend-item active"><span class="dot"></span> ACTIVE ON ROAD</span>
                <span class="legend-item upcoming"><span class="dot"></span> UPCOMING NEXT</span>
                <span class="legend-item completed"><span class="dot"></span> COMPLETED</span>
            </div>
        </div>

        <!-- Hidden message container (used only for discreet transient notices) -->
        <p class="driveflow-message" data-board-message style="display:none;"></p>
        
        <!-- Live sessions cards list -->
        <div class="driveflow-tv-grid" data-session-list>
            <?php if (!empty($today_sessions)) : ?>
                <?php foreach ($today_sessions as $s) : 
                    $is_active = ('active' === $s['status']);
                    $is_completed = ('completed' === $s['status']);
                    $card_class = $is_active ? 'is-active' : ($is_completed ? 'is-completed' : 'is-upcoming');
                    $status_class = $is_active ? 'active' : ($is_completed ? 'completed' : 'upcoming');
                    $status_text = $is_active ? 'ACTIVE · ON ROAD' : ($is_completed ? 'COMPLETED' : 'UPCOMING NEXT');
                    $plate = !empty($s['plate_number']) ? strtoupper($s['plate_number']) : 'MVA-REG';
                    $start_time = !empty($s['scheduled_start']) ? date_i18n('g:i A', strtotime($s['scheduled_start'])) : '--:--';
                    $end_time = !empty($s['scheduled_end']) ? date_i18n('g:i A', strtotime($s['scheduled_end'])) : '--:--';
                ?>
                    <article class="driveflow-tv-card <?php echo esc_attr($card_class); ?>">
                        <div class="df-card-top">
                            <?php echo DriveFlow_Pro::render_maryland_plate($plate, 'sm'); ?>
                            <div class="df-card-status-badge <?php echo esc_attr($status_class); ?>">
                                <span class="df-pulsing-dot-sm"></span> <?php echo esc_html($status_text); ?>
                            </div>
                        </div>
                        <div class="df-card-mid">
                            <div class="df-card-student-wrap">
                                <span class="df-student-avatar">🎓</span>
                                <h3 class="df-card-student"><?php echo esc_html($s['student_name'] ?: 'Enrolled Student'); ?></h3>
                            </div>
                            <div class="df-card-meta-row">
                                <span class="df-meta-pill instructor">👨‍🏫 <?php echo esc_html($s['instructor_name'] ?: 'Assigned Instructor'); ?></span>
                                <span class="df-meta-pill topic">🚗 Lesson <?php echo esc_html($s['session_number'] ?: 1); ?><?php if (!empty($s['lesson_topic'])) : ?> · <?php echo esc_html($s['lesson_topic']); ?><?php endif; ?></span>
                            </div>
                        </div>
                        <div class="df-card-time-bar">
                            <span class="df-time-clock">🕒</span>
                            <span class="df-time-range"><?php echo esc_html($start_time . ' – ' . $end_time); ?></span>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php else : ?>
                <!-- Standby Welcome Card when no sessions are currently on road -->
                <div class="df-tv-standby-card">
                    <div class="df-tv-standby-icon">🚗</div>
                    <div class="df-tv-standby-badge">
                        <span class="df-pulsing-dot-sm"></span> Training Fleet Active & On Standby
                    </div>
                    <h3 class="df-tv-standby-title">Certified Instructors & Dual-Control Vehicles Ready</h3>
                    <p class="df-tv-standby-desc">
                        Today's driving sessions will appear here live in real-time as instructors activate in-car evaluations and dispatch onto the road.
                    </p>
                    <div class="df-tv-standby-footer">
                        <span class="df-standby-tag">🛡️ Dual-Control Safety Certified</span>
                        <span class="df-standby-tag">🏛️ Maryland MVA / COMAR 11.23 Compliant</span>
                        <span class="df-standby-tag">📍 Rockville, MD</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Announcement Ticker Footer -->
    <footer class="driveflow-tv-ticker">
        <div class="df-ticker-badge">ANNOUNCEMENT</div>
        <div class="df-ticker-scroll-wrap">
            <div class="df-ticker-text" data-ticker-content>
                <?php echo esc_html(!empty($brand['ticker']) ? $brand['ticker'] : 'Welcome to DriveFlow Academy • Please have your Maryland learner permit ready before your driving session • Safe driving is respect for life.'); ?>
            </div>
        </div>
    </footer>
</div>
