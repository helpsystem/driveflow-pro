<?php
defined('ABSPATH') || exit;

/**
 * DriveFlow Pro - Instructor Mobile & Tablet In-Car Evaluation App
 * Official Driver Education Student In-Car Evaluation / Progress Record
 */
$school_name = !empty($brand['name']) ? $brand['name'] : 'SAM Driving School';
$logo_url = !empty($brand['logo']) ? $brand['logo'] : '';
?>

<div class="sam-eval-container" id="driveflow-instructor-app" dir="ltr">
  <style>
    .sam-eval-container {
      max-width: 980px;
      margin: 15px auto;
      background: #ffffff;
      padding: 24px 30px;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      color: #1f2937;
      direction: ltr;
      text-align: left;
    }
    .sam-eval-header {
      text-align: center;
      border-bottom: 2px solid #e5e7eb;
      padding-bottom: 18px;
      margin-bottom: 20px;
      position: relative;
    }
    .sam-eval-header h1 {
      margin: 0;
      font-size: 24px;
      font-weight: 800;
      color: #111827;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .sam-eval-header h2 {
      margin: 6px 0 0;
      font-size: 16px;
      font-weight: 700;
      color: #16a34a;
    }
    .sam-top-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #f0fdf4;
      color: #16a34a;
      border: 1px solid #bbf7d0;
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 700;
      margin-bottom: 8px;
    }
    .sam-pulse-dot {
      width: 7px;
      height: 7px;
      background: #16a34a;
      border-radius: 50%;
      box-shadow: 0 0 8px #16a34a;
      animation: samPulse 1.5s infinite;
    }
    @keyframes samPulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.5; transform: scale(1.3); }
    }
    .sam-instructor-bar {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 18px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
    }
    .sam-today-sessions-wrap {
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 8px;
      padding: 12px 16px;
      margin-bottom: 20px;
    }
    .sam-sessions-carousel {
      display: flex;
      gap: 10px;
      overflow-x: auto;
      padding-top: 8px;
      padding-bottom: 4px;
    }
    .sam-session-chip {
      background: #ffffff;
      border: 1px solid #93c5fd;
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 12px;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.2s;
    }
    .sam-session-chip:hover {
      background: #2563eb;
      color: #ffffff;
      border-color: #1d4ed8;
    }
    .sam-session-chip.is-active {
      background: #2563eb;
      color: #ffffff;
      border-color: #1d4ed8;
      font-weight: 700;
    }
    .sam-meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 14px;
      margin-bottom: 20px;
      background: #f9fafb;
      padding: 16px;
      border-radius: 8px;
      border: 1px solid #e5e7eb;
    }
    .sam-input-group label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      color: #4b5563;
      text-transform: uppercase;
      margin-bottom: 4px;
      letter-spacing: 0.3px;
    }
    .sam-input-group input, .sam-input-group select {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 13px;
      box-sizing: border-box;
      outline: none;
      background: #ffffff;
      transition: border 0.2s;
    }
    .sam-input-group input:focus, .sam-input-group select:focus {
      border-color: #16a34a;
    }
    .sam-scale-box {
      background: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-radius: 8px;
      padding: 12px 16px;
      margin-bottom: 20px;
    }
    .sam-scale-box p {
      margin: 0 0 6px;
      font-weight: 700;
      font-size: 13px;
      color: #166534;
    }
    .sam-scale-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
      gap: 6px;
      font-size: 12px;
      color: #374151;
    }
    .sam-eval-table-wrap {
      overflow-x: auto;
      margin-bottom: 25px;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
    }
    .sam-eval-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
      background: #fff;
    }
    .sam-eval-table th, .sam-eval-table td {
      border: 1px solid #e5e7eb;
      padding: 7px 8px;
    }
    .sam-eval-table th {
      background: #f3f4f6;
      font-weight: 700;
      color: #1f2937;
      text-align: center;
      font-size: 12px;
    }
    .sam-eval-table th.skill-col {
      text-align: left;
      width: 46%;
    }
    .sam-eval-table td select {
      width: 100%;
      padding: 4px;
      border: 1px solid #d1d5db;
      border-radius: 4px;
      font-size: 13px;
      text-align: center;
      background: #fff;
      font-weight: 600;
    }
    .sam-eval-table td select:focus {
      border-color: #16a34a;
    }
    .sam-section-title {
      background: #e5e7eb;
      font-weight: 800;
      color: #374151;
      padding: 8px 12px;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    /* Extra utilities: Stopwatch & Selfie */
    .sam-addon-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 20px;
    }
    .sam-addon-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
    }
    .sam-addon-title {
      font-size: 12px;
      font-weight: 700;
      color: #475569;
      text-transform: uppercase;
      margin-bottom: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .sam-timer-display {
      font-family: monospace;
      font-size: 22px;
      font-weight: 800;
      color: #0f172a;
    }
    .sam-btn-sm {
      padding: 4px 10px;
      border-radius: 4px;
      border: 1px solid #cbd5e1;
      background: #fff;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .sam-footer-box {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      padding: 20px;
      margin-top: 20px;
    }
    .sam-eval-result {
      display: flex;
      align-items: center;
      gap: 20px;
      margin-bottom: 18px;
      padding-bottom: 15px;
      border-bottom: 1px dashed #d1d5db;
    }
    .sam-eval-result label {
      font-weight: 700;
      font-size: 14px;
    }
    .sam-radio-opt {
      display: flex;
      align-items: center;
      gap: 6px;
      font-weight: 700;
      cursor: pointer;
      font-size: 14px;
    }
    .sam-signatures {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    .sig-canvas-wrap {
      border: 1.5px dashed #9ca3af;
      background: #fff;
      border-radius: 6px;
      height: 95px;
      position: relative;
      touch-action: none;
    }
    .sig-canvas-wrap canvas {
      width: 100%;
      height: 100%;
      display: block;
    }
    .sig-clear-btn {
      position: absolute;
      top: 4px;
      right: 4px;
      font-size: 10px;
      background: #fee2e2;
      color: #b91c1c;
      border: 1px solid #fca5a5;
      padding: 2px 7px;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
    }
    .sig-clear-btn:hover {
      background: #ef4444;
      color: #fff;
    }
    .sam-submit-btn {
      display: block;
      width: 100%;
      background: #16a34a;
      color: #fff;
      font-weight: 800;
      font-size: 16px;
      padding: 14px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      margin-top: 24px;
      transition: background 0.2s, transform 0.1s;
      letter-spacing: 0.3px;
    }
    .sam-submit-btn:hover {
      background: #15803d;
      transform: translateY(-1px);
    }
    .sam-submit-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    .sam-feedback-alert {
      display: none;
      padding: 14px 18px;
      border-radius: 8px;
      margin-top: 18px;
      font-size: 14px;
      font-weight: 600;
    }
    .sam-feedback-success {
      background: #f0fdf4;
      border: 1px solid #bbf7d0;
      color: #15803d;
    }
    .sam-feedback-error {
      background: #fef2f2;
      border: 1px solid #fecaca;
      color: #b91c1c;
    }
    @media (max-width: 680px) {
      .sam-eval-container { padding: 16px; }
      .sam-signatures { grid-template-columns: 1fr; }
      .sam-addon-grid { grid-template-columns: 1fr; }
    }
  </style>

  <!-- Form -->
  <form id="mvaInCarEvalForm">
    <input type="hidden" name="action" value="driveflow_submit_evaluation">
    <input type="hidden" name="session_id" id="sam-session-id" value="0">
    <input type="hidden" name="instructor_signature_data" id="instructorSigInput">
    <input type="hidden" name="student_signature_data" id="studentSigInput">
    <input type="hidden" name="selfie" id="samSelfieInput">

    <!-- Header -->
    <div class="sam-eval-header">
      <div class="sam-top-badge"><span class="sam-pulse-dot"></span> In-Car Instructor Terminal</div>
      <?php if (!empty($logo_url)) : ?>
        <div style="margin-bottom:8px;"><img src="<?php echo esc_url($logo_url); ?>" alt="" style="max-height:45px;max-width:160px;"></div>
      <?php endif; ?>
      <h1><?php echo esc_html($school_name); ?></h1>
      <h2>Driver Education Student In-Car Evaluation / Progress Record</h2>
    </div>

    <!-- Instructor Active Profile Bar -->
    <div class="sam-instructor-bar">
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:24px;">👨‍🏫</span>
        <div>
          <strong style="font-size:14px;color:#0f172a;" id="sam-active-instructor-label">Select Assigned Instructor:</strong>
          <div style="font-size:12px;color:#64748b;">In-car evaluation and progress record sign-off</div>
        </div>
      </div>
      <div style="min-width:220px;">
        <select id="sam-instructor-quick-select" class="sam-input-group" style="width:100%;padding:6px 10px;border-radius:6px;border:1px solid #cbd5e1;font-size:13px;font-weight:600;">
          <option value="">-- Choose Instructor Profile --</option>
          <?php if (!empty($instructors)) : foreach ($instructors as $ins) : ?>
            <option value="<?php echo esc_attr($ins['name']); ?>" data-cert="<?php echo esc_attr($ins['license_number']); ?>">
              <?php echo esc_html($ins['name']); ?> (Lic: <?php echo esc_html($ins['license_number'] ?: 'MVA'); ?>)
            </option>
          <?php endforeach; endif; ?>
        </select>
      </div>
    </div>

    <!-- Today's Assigned Sessions Quick Picker -->
    <?php if (!empty($today_sessions)) : ?>
      <div class="sam-today-sessions-wrap">
        <div style="font-size:12px;font-weight:700;color:#1e40af;text-transform:uppercase;letter-spacing:0.3px;">
          📅 Today's Scheduled Lessons (Tap to Load Student):
        </div>
        <div class="sam-sessions-carousel">
          <?php foreach ($today_sessions as $ts) : 
            $time_fmt = date_i18n('g:i A', strtotime($ts['scheduled_start']));
          ?>
            <div class="sam-session-chip" 
                 data-session-id="<?php echo esc_attr($ts['id']); ?>"
                 data-student="<?php echo esc_attr($ts['student_name']); ?>"
                 data-instructor="<?php echo esc_attr($ts['instructor_name']); ?>"
                 data-plate="<?php echo esc_attr($ts['plate_number']); ?>"
                 data-number="<?php echo esc_attr($ts['session_number']); ?>"
                 data-start="<?php echo esc_attr($ts['scheduled_start']); ?>"
                 data-end="<?php echo esc_attr($ts['scheduled_end']); ?>">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                <strong>#<?php echo esc_html($ts['session_number']); ?></strong> <?php echo esc_html($ts['student_name']); ?> • <?php echo esc_html($time_fmt); ?>
                <?php if (!empty($ts['plate_number'])) echo DriveFlow_Pro::render_maryland_plate($ts['plate_number'], 'sm'); ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Student & Instructor Info Meta Grid -->
    <div class="sam-meta-grid">
      <div class="sam-input-group">
        <label>Student Name *</label>
        <input type="text" name="student_name" id="sam-student-name" required placeholder="Full Legal Name" list="sam-students-list">
        <datalist id="sam-students-list">
          <?php if (!empty($students)) : foreach ($students as $st) : ?>
            <option value="<?php echo esc_attr($st['name']); ?>"><?php echo esc_html($st['name']); ?> (Permit: <?php echo esc_html($st['license_number']); ?>)</option>
          <?php endforeach; endif; ?>
        </datalist>
      </div>

      <div class="sam-input-group">
        <label>Instructor Name *</label>
        <input type="text" name="instructor_name" id="sam-instructor-name" required placeholder="Instructor Name">
      </div>

      <div class="sam-input-group">
        <label>Instructor License #</label>
        <input type="text" name="instructor_cert_no" id="sam-instructor-cert" placeholder="MVA Lic. / Cert #">
      </div>

      <div class="sam-input-group">
        <label>Fleet Vehicle Plate</label>
        <select name="plate_number" id="sam-vehicle-plate">
          <option value="">Select Training Vehicle...</option>
          <?php if (!empty($vehicles)) : foreach ($vehicles as $veh) : ?>
            <option value="<?php echo esc_attr($veh['plate_number']); ?>">
              <?php echo esc_html($veh['plate_number']); ?> (<?php echo esc_html($veh['model']); ?>)
            </option>
          <?php endforeach; endif; ?>
        </select>
        <div id="sam-plate-preview" style="margin-top:6px;"></div>
      </div>

      <div class="sam-input-group">
        <label>Lesson Number</label>
        <input type="number" name="session_number" id="sam-session-number" value="1" min="1" max="50">
      </div>

      <div class="sam-input-group">
        <label>Curriculum Focus Topic</label>
        <input type="text" name="lesson_topic" id="sam-lesson-topic" placeholder="e.g. Parallel Parking & Highway Driving" value="Behind-The-Wheel Driving Lesson">
      </div>
    </div>

    <!-- Lesson Dates (Sessions 1-6) -->
    <div class="sam-meta-grid" style="grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));">
      <div class="sam-input-group"><label>Dates: Lesson 1</label><input type="date" name="date_l1" id="sam-date-l1" value="<?php echo esc_attr(date('Y-m-d')); ?>"></div>
      <div class="sam-input-group"><label>Dates: Lesson 2</label><input type="date" name="date_l2"></div>
      <div class="sam-input-group"><label>Dates: Lesson 3</label><input type="date" name="date_l3"></div>
      <div class="sam-input-group"><label>Dates: Lesson 4</label><input type="date" name="date_l4"></div>
      <div class="sam-input-group"><label>Dates: Lesson 5</label><input type="date" name="date_l5"></div>
      <div class="sam-input-group"><label>Dates: Lesson 6</label><input type="date" name="date_l6"></div>
    </div>

    <!-- Scoring Legend Guide -->
    <div class="sam-scale-box">
      <p>Rating Scale Guide:</p>
      <div class="sam-scale-grid">
        <div><strong>4</strong> = Performs without coaching</div>
        <div><strong>3</strong> = Occasional coaching</div>
        <div><strong>2</strong> = Significant coaching</div>
        <div><strong>1</strong> = Does not perform adequately</div>
      </div>
    </div>

    <!-- Skills Table Container -->
    <div class="sam-eval-table-wrap">
      <table class="sam-eval-table">
        <thead>
          <tr>
            <th class="skill-col">Skills & Performance Criteria</th>
            <th>L-1</th>
            <th>L-2</th>
            <th>L-3</th>
            <th>L-4</th>
            <th>L-5</th>
            <th>L-6</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $skills = array(
            "Pre-entry checks",
            "Pre-start and starting",
            "Moving forward",
            "Moving backward",
            "Entering traffic",
            "Right Turns",
            "Left turns",
            "Negotiating intersections",
            "Changing lanes",
            "Slowing and stopping",
            "Parking and securing",
            "Parking on grades",
            "Angle parking",
            "Parallel parking",
            "Turnabouts",
            "Assessing highway conditions",
            "Space management",
            "Response to traffic controls",
            "Response to other users",
            "Passing",
            "Commentary driving",
            "Speed"
          );

          $conditions = array(
            "Adverse weather",
            "Night driving"
          );

          foreach ($skills as $idx => $skill) : ?>
            <tr>
              <td><strong><?php echo esc_html($skill); ?></strong></td>
              <?php for ($i = 1; $i <= 6; $i++) : ?>
                <td>
                  <select name="skill_<?php echo $idx; ?>_l<?php echo $i; ?>">
                    <option value="">-</option>
                    <option value="4" <?php selected($i, 1); ?>>4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                  </select>
                </td>
              <?php endfor; ?>
            </tr>
          <?php endforeach; ?>

          <tr>
            <td colspan="7" class="sam-section-title">Driving Conditions (When Appropriate)</td>
          </tr>

          <?php foreach ($conditions as $c_idx => $cond) : ?>
            <tr>
              <td><?php echo esc_html($cond); ?></td>
              <?php for ($i = 1; $i <= 6; $i++) : ?>
                <td>
                  <select name="cond_<?php echo $c_idx; ?>_l<?php echo $i; ?>">
                    <option value="">-</option>
                    <option value="4">4</option>
                    <option value="3">3</option>
                    <option value="2">2</option>
                    <option value="1">1</option>
                  </select>
                </td>
              <?php endfor; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- In-Car Utilities: Live Stopwatch & Selfie Photo Verification -->
    <div class="sam-addon-grid">
      <!-- Stopwatch Timer -->
      <div class="sam-addon-box">
        <div class="sam-addon-title">
          <span>⏱️ In-Car Session Timer</span>
          <div>
            <button type="button" class="sam-btn-sm" id="sam-timer-btn" style="background:#16a34a;color:#fff;border-color:#15803d;">▶ Start</button>
            <button type="button" class="sam-btn-sm" id="sam-timer-reset">Reset</button>
          </div>
        </div>
        <div class="sam-timer-display" id="sam-timer-digits">00:00:00</div>
        <small style="color:#64748b;font-size:11px;">Track exact behind-the-wheel instruction duration.</small>
      </div>

      <!-- Instructor Selfie Verification -->
      <div class="sam-addon-box">
        <div class="sam-addon-title">
          <span>📸 In-Car Verification Photo</span>
          <div>
            <button type="button" class="sam-btn-sm" id="sam-camera-btn">📷 Camera</button>
            <button type="button" class="sam-btn-sm" id="sam-flip-btn" style="display:none;">🔄 Flip</button>
            <button type="button" class="sam-btn-sm" id="sam-snap-btn" style="display:none;background:#2563eb;color:#fff;">✓ Capture</button>
          </div>
        </div>
        <div style="position:relative;background:#0f172a;border-radius:6px;height:70px;overflow:hidden;display:flex;align-items:center;justify-content:center;">
          <video id="sam-video" autoplay muted playsinline style="display:none;width:100%;height:100%;object-fit:cover;"></video>
          <canvas id="sam-snap-canvas" style="display:none;"></canvas>
          <img id="sam-selfie-preview" alt="" style="display:none;max-height:100%;object-fit:contain;">
          <span id="sam-cam-placeholder" style="color:#94a3b8;font-size:11px;">Tap Camera to verify presence</span>
        </div>
      </div>
    </div>

    <!-- Instructor Notes / Feedback -->
    <div style="margin-bottom:20px;">
      <label style="display:block;font-size:12px;font-weight:700;color:#374151;margin-bottom:6px;text-transform:uppercase;">
        Instructor Feedback & Coaching Recommendations (Emailed to Student):
      </label>
      <textarea name="instructor_notes" rows="2" placeholder="e.g. Excellent progress on parallel parking and lane changes. Continue practicing mirror checks and speed management when approaching intersections." style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;box-sizing:border-box;outline:none;"></textarea>
    </div>

    <!-- Final Evaluation & Signatures -->
    <div class="sam-footer-box">
      <div class="sam-eval-result">
        <label>Final Evaluation:</label>
        <label class="sam-radio-opt" style="color: #15803d;">
          <input type="radio" name="final_evaluation" value="Pass" checked required> PASS
        </label>
        <label class="sam-radio-opt" style="color: #b91c1c;">
          <input type="radio" name="final_evaluation" value="Fail" required> FAIL
        </label>
      </div>

      <div class="sam-signatures">
        <!-- Instructor Signature -->
        <div>
          <label style="display:block; font-size: 12px; font-weight:700; margin-bottom: 6px; color:#111827;">
            Instructor Signature & Date:
          </label>
          <div class="sig-canvas-wrap">
            <button type="button" class="sig-clear-btn" onclick="clearSignatureCanvas('instructorSig', 'instructorSigInput')">Clear</button>
            <canvas id="instructorSig"></canvas>
          </div>
          <small style="color:#64748b;font-size:11px;">Sign with finger or stylus</small>
        </div>

        <!-- Student/Driver Signature -->
        <div>
          <label style="display:block; font-size: 12px; font-weight:700; margin-bottom: 6px; color:#111827;">
            Driver / Student Signature & Date:
          </label>
          <div class="sig-canvas-wrap">
            <button type="button" class="sig-clear-btn" onclick="clearSignatureCanvas('studentSig', 'studentSigInput')">Clear</button>
            <canvas id="studentSig"></canvas>
          </div>
          <small style="color:#64748b;font-size:11px;">Student signs on tablet/phone screen</small>
        </div>
      </div>
    </div>

    <!-- Submit Button & Feedback -->
    <button type="submit" class="sam-submit-btn" id="sam-submit-btn">
      Save & Submit Evaluation Record
    </button>
    <div id="sam-feedback-alert" class="sam-feedback-alert"></div>
  </form>

  <script>
    function setupSignaturePad(canvasId, inputId) {
      const canvas = document.getElementById(canvasId);
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let drawing = false;

      function resize() {
        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width || 350;
        canvas.height = rect.height || 95;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#0f172a';
      }
      resize();
      window.addEventListener('resize', resize);

      function getPos(e) {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return { x: clientX - rect.left, y: clientY - rect.top };
      }

      function start(e) {
        drawing = true;
        const p = getPos(e);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
      }
      function move(e) {
        if (!drawing) return;
        if (e.cancelable && e.type.startsWith('touch')) e.preventDefault();
        const p = getPos(e);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
      }
      function stop() {
        if (drawing) {
          drawing = false;
          document.getElementById(inputId).value = canvas.toDataURL('image/png');
        }
      }

      canvas.addEventListener('mousedown', start);
      canvas.addEventListener('mousemove', move);
      window.addEventListener('mouseup', stop);

      canvas.addEventListener('touchstart', start, { passive: false });
      canvas.addEventListener('touchmove', move, { passive: false });
      window.addEventListener('touchend', stop);
    }

    function clearSignatureCanvas(canvasId, inputId) {
      const canvas = document.getElementById(canvasId);
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const input = document.getElementById(inputId);
      if (input) input.value = '';
    }

    // Initialize both signatures
    setupSignaturePad('instructorSig', 'instructorSigInput');
    setupSignaturePad('studentSig', 'studentSigInput');

    // Instructor Quick Select handler
    const insSelect = document.getElementById('sam-instructor-quick-select');
    if (insSelect) {
      insSelect.addEventListener('change', function() {
        const val = this.value;
        const cert = this.options[this.selectedIndex].getAttribute('data-cert') || '';
        document.getElementById('sam-instructor-name').value = val;
        document.getElementById('sam-instructor-cert').value = cert;
        if (val) {
          document.getElementById('sam-active-instructor-label').textContent = 'Active Instructor: ' + val;
        }
      });
    }

    // Today's session chips click handler
    document.querySelectorAll('.sam-session-chip').forEach(function(chip) {
      chip.addEventListener('click', function() {
        document.querySelectorAll('.sam-session-chip').forEach(c => c.classList.remove('is-active'));
        this.classList.add('is-active');

        document.getElementById('sam-session-id').value = this.dataset.sessionId || '0';
        document.getElementById('sam-student-name').value = this.dataset.student || '';
        document.getElementById('sam-instructor-name').value = this.dataset.instructor || '';
        document.getElementById('sam-session-number').value = this.dataset.number || '1';
        document.getElementById('sam-lesson-topic').value = this.dataset.topic || 'Behind-The-Wheel Driving Lesson';
        
        const plate = this.dataset.plate || '';
        const plateSelect = document.getElementById('sam-vehicle-plate');
        if (plate && plateSelect) {
          plateSelect.value = plate;
          updatePlatePreview(plate);
        }
      });
    });

    function updatePlatePreview(plate) {
      const prev = document.getElementById('sam-plate-preview');
      if (!prev) return;
      if (plate) {
        prev.innerHTML = '<div class="maryland-plate plate-sm" title="Maryland Registration: ' + plate + ' (Click to Preview)" data-plate="' + plate + '" role="button" tabindex="0"><span class="plate-bolt bolt-tl"></span><span class="plate-bolt bolt-tr"></span><span class="plate-number">' + plate + '</span><span class="plate-bolt bolt-bl"></span><span class="plate-bolt bolt-br"></span><span class="plate-shine"></span></div>';
      } else {
        prev.innerHTML = '';
      }
    }
    const plateSelectEl = document.getElementById('sam-vehicle-plate');
    if (plateSelectEl) {
      plateSelectEl.addEventListener('change', function() {
        updatePlatePreview(this.value);
      });
    }

    // Stopwatch Timer
    let timerInterval = null;
    let timerSeconds = 0;
    let timerRunning = false;
    const timerBtn = document.getElementById('sam-timer-btn');
    const timerReset = document.getElementById('sam-timer-reset');
    const timerDigits = document.getElementById('sam-timer-digits');

    function pad2(n) { return n < 10 ? '0' + n : n; }
    function renderTimer() {
      const h = Math.floor(timerSeconds / 3600);
      const m = Math.floor((timerSeconds % 3600) / 60);
      const s = timerSeconds % 60;
      timerDigits.textContent = pad2(h) + ':' + pad2(m) + ':' + pad2(s);
    }

    if (timerBtn) {
      timerBtn.addEventListener('click', function() {
        timerRunning = !timerRunning;
        if (timerRunning) {
          timerBtn.textContent = '⏸ Pause';
          timerBtn.style.background = '#f59e0b';
          timerBtn.style.borderColor = '#d97706';
          timerInterval = setInterval(function() {
            timerSeconds++;
            renderTimer();
          }, 1000);
        } else {
          timerBtn.textContent = '▶ Resume';
          timerBtn.style.background = '#16a34a';
          timerBtn.style.borderColor = '#15803d';
          clearInterval(timerInterval);
        }
      });
    }

    if (timerReset) {
      timerReset.addEventListener('click', function() {
        timerRunning = false;
        clearInterval(timerInterval);
        timerSeconds = 0;
        renderTimer();
        timerBtn.textContent = '▶ Start';
        timerBtn.style.background = '#16a34a';
        timerBtn.style.borderColor = '#15803d';
      });
    }

    // Camera handling
    let camStream = null;
    let useFront = true;
    const camBtn = document.getElementById('sam-camera-btn');
    const flipBtn = document.getElementById('sam-flip-btn');
    const snapBtn = document.getElementById('sam-snap-btn');
    const video = document.getElementById('sam-video');
    const placeholder = document.getElementById('sam-cam-placeholder');
    const preview = document.getElementById('sam-selfie-preview');

    function startInCarCamera() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Camera not supported on this device browser.');
        return;
      }
      if (camStream) camStream.getTracks().forEach(t => t.stop());

      navigator.mediaDevices.getUserMedia({
        video: { facingMode: useFront ? 'user' : 'environment' },
        audio: false
      }).then(function(stream) {
        camStream = stream;
        video.srcObject = stream;
        video.style.display = 'block';
        if (placeholder) placeholder.style.display = 'none';
        if (preview) preview.style.display = 'none';
        flipBtn.style.display = 'inline-block';
        snapBtn.style.display = 'inline-block';
        camBtn.textContent = 'Active ✓';
      }).catch(function(err) {
        alert('Could not start camera: ' + err.message);
      });
    }

    if (camBtn) camBtn.addEventListener('click', startInCarCamera);
    if (flipBtn) flipBtn.addEventListener('click', function() { useFront = !useFront; startInCarCamera(); });
    if (snapBtn) {
      snapBtn.addEventListener('click', function() {
        const snapCanvas = document.getElementById('sam-snap-canvas');
        snapCanvas.width = video.videoWidth || 640;
        snapCanvas.height = video.videoHeight || 480;
        const ctx = snapCanvas.getContext('2d');
        ctx.drawImage(video, 0, 0, snapCanvas.width, snapCanvas.height);
        const dataUrl = snapCanvas.toDataURL('image/jpeg', 0.85);
        document.getElementById('samSelfieInput').value = dataUrl;

        preview.src = dataUrl;
        preview.style.display = 'block';
        video.style.display = 'none';
        if (camStream) camStream.getTracks().forEach(t => t.stop());
      });
    }

    // Form Submission
    document.getElementById('mvaInCarEvalForm').addEventListener('submit', function(e) {
      e.preventDefault();
      const form = this;
      const submitBtn = document.getElementById('sam-submit-btn');
      const feedback = document.getElementById('sam-feedback-alert');

      submitBtn.disabled = true;
      submitBtn.textContent = 'Saving Evaluation Record & Dispatching Scorecard...';
      feedback.style.display = 'none';

      const formData = new FormData(form);
      const ajaxUrl = (window.DriveFlowPro && window.DriveFlowPro.ajaxurl) ? window.DriveFlowPro.ajaxurl : '/wp-admin/admin-ajax.php';

      fetch(ajaxUrl, {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Save & Submit Evaluation Record';

        if (res && res.success) {
          feedback.className = 'sam-feedback-alert sam-feedback-success';
          feedback.innerHTML = '<strong>✓ Evaluation Saved Successfully!</strong> ' + (res.data.message || 'Record logged and student scorecard issued.') + ' [Status: ' + (res.data.evaluation || 'PASS') + ']';
          feedback.style.display = 'block';
          window.scrollTo({ top: feedback.offsetTop - 40, behavior: 'smooth' });
        } else {
          feedback.className = 'sam-feedback-alert sam-feedback-error';
          feedback.innerHTML = '<strong>✕ Submission Error:</strong> ' + ((res && res.data && res.data.message) || 'Failed to save record.');
          feedback.style.display = 'block';
        }
      })
      .catch(err => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Save & Submit Evaluation Record';
        feedback.className = 'sam-feedback-alert sam-feedback-error';
        feedback.innerHTML = '<strong>✕ Network Error:</strong> Could not connect to WordPress server.';
        feedback.style.display = 'block';
      });
    });
  </script>
</div>
