(function () {
    'use strict';
    var config = window.DriveFlowPro || {};

    function request(path, options) {
        options = options || {};
        options.headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
        if (config.nonce) options.headers['X-WP-Nonce'] = config.nonce;
        return fetch((config.root || '') + path, options).then(function (response) {
            return response.json().then(function (body) {
                if (!response.ok) throw new Error(body.message || 'Network communication error');
                return body;
            });
        });
    }

    function setMessage(element, text, isError) {
        if (!element) return;
        element.textContent = text;
        element.classList.toggle('is-error', Boolean(isError));
    }

    // Modern Signature Pad
    function initSignature(form) {
        var canvas = form.querySelector('[data-signature-canvas]');
        var input = form.querySelector('[data-signature-input]');
        if (!canvas || !input) return;

        var context = canvas.getContext('2d');
        var drawing = false;

        function resize() {
            var ratio = window.devicePixelRatio || 1;
            var width = canvas.clientWidth || 600;
            var height = canvas.clientHeight || 180;
            canvas.width = width * ratio;
            canvas.height = height * ratio;
            context.scale(ratio, ratio);
            context.strokeStyle = '#0f172a';
            context.lineWidth = 2.5;
            context.lineCap = 'round';
            context.lineJoin = 'round';
        }

        function point(event) {
            var rect = canvas.getBoundingClientRect();
            return { x: event.clientX - rect.left, y: event.clientY - rect.top };
        }

        canvas.addEventListener('pointerdown', function (event) {
            drawing = true;
            canvas.setPointerCapture(event.pointerId);
            var p = point(event);
            context.beginPath();
            context.moveTo(p.x, p.y);
        });

        canvas.addEventListener('pointermove', function (event) {
            if (!drawing) return;
            var p = point(event);
            context.lineTo(p.x, p.y);
            context.stroke();
            input.value = canvas.toDataURL('image/png');
        });

        ['pointerup', 'pointercancel'].forEach(function (name) {
            canvas.addEventListener(name, function () { drawing = false; });
        });

        var clearBtn = form.querySelector('[data-clear-signature]');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                context.clearRect(0, 0, canvas.width, canvas.height);
                input.value = '';
            });
        }

        resize();
        window.addEventListener('resize', resize);
    }

    // Stopwatch Timer
    function initTimer(form) {
        var digits = form.querySelector('[data-timer-digits]');
        var toggleBtn = form.querySelector('[data-timer-toggle]');
        var resetBtn = form.querySelector('[data-timer-reset]');
        if (!digits || !toggleBtn) return;

        var timerInterval = null;
        var secondsElapsed = 0;
        var running = false;

        function renderDigits() {
            var h = Math.floor(secondsElapsed / 3600);
            var m = Math.floor((secondsElapsed % 3600) / 60);
            var s = secondsElapsed % 60;
            var pad = function (n) { return n < 10 ? '0' + n : n; };
            digits.textContent = pad(h) + ':' + pad(m) + ':' + pad(s);
        }

        toggleBtn.addEventListener('click', function () {
            running = !running;
            if (running) {
                toggleBtn.textContent = '⏸ Pause Timer';
                toggleBtn.style.background = '#f59e0b';
                toggleBtn.style.color = '#000';
                timerInterval = window.setInterval(function () {
                    secondsElapsed++;
                    renderDigits();
                }, 1000);
            } else {
                toggleBtn.textContent = '▶ Resume Timer';
                toggleBtn.style.background = '';
                toggleBtn.style.color = '';
                window.clearInterval(timerInterval);
            }
        });

        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                running = false;
                window.clearInterval(timerInterval);
                secondsElapsed = 0;
                renderDigits();
                toggleBtn.textContent = '▶ Start Lesson Timer';
                toggleBtn.style.background = '';
                toggleBtn.style.color = '';
            });
        }
    }

    // Interactive Star Rating Controller
    function initStarRatings(form) {
        var groups = form.querySelectorAll('.df-star-group');
        groups.forEach(function (group) {
            var input = group.querySelector('input[type="hidden"]');
            var stars = group.querySelectorAll('.df-star');
            stars.forEach(function (star) {
                star.addEventListener('click', function () {
                    var val = parseInt(star.getAttribute('data-val'), 10) || 1;
                    if (input) input.value = val;
                    stars.forEach(function (s) {
                        var sVal = parseInt(s.getAttribute('data-val'), 10) || 1;
                        s.classList.toggle('is-active', sVal <= val);
                    });
                });
            });
        });
    }

    // Instructor Form Controller
    function initForm(form) {
        var video = form.querySelector('[data-camera]');
        var canvas = form.querySelector('[data-selfie-canvas]');
        var preview = form.querySelector('[data-selfie-preview]');
        var selfieInput = form.querySelector('[data-selfie-input]');
        var cameraButton = form.querySelector('[data-start-camera]');
        var flipButton = form.querySelector('[data-flip-camera]');
        var captureButton = form.querySelector('[data-capture-selfie]');
        var submitBtn = form.querySelector('[data-submit-btn]');
        var message = form.querySelector('[data-form-message]');

        var stream = null;
        var useFrontCamera = true;

        // Auto-set current time and default +2 hours for scheduled start/end
        var now = new Date();
        var pad = function (n) { return n < 10 ? '0' + n : n; };
        var startIso = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + 'T' + pad(now.getHours()) + ':' + pad(now.getMinutes());
        var endD = new Date(now.getTime() + 2 * 60 * 60 * 1000);
        var endIso = endD.getFullYear() + '-' + pad(endD.getMonth() + 1) + '-' + pad(endD.getDate()) + 'T' + pad(endD.getHours()) + ':' + pad(endD.getMinutes());

        var startInput = form.querySelector('#driveflow-form-start');
        var endInput = form.querySelector('#driveflow-form-end');
        if (startInput && !startInput.value) startInput.value = startIso;
        if (endInput && !endInput.value) endInput.value = endIso;

        // Load directory (students, instructors, vehicles)
        request('/directory').then(function (dir) {
            var stDatalist = form.querySelector('#driveflow-students');
            if (stDatalist && dir.students) {
                dir.students.forEach(function (s) {
                    var opt = document.createElement('option');
                    opt.value = s.student_name;
                    stDatalist.appendChild(opt);
                });
            }

            var insDatalist = form.querySelector('#driveflow-instructors');
            if (insDatalist && dir.instructors) {
                dir.instructors.forEach(function (ins) {
                    var opt = document.createElement('option');
                    opt.value = ins.instructor_name;
                    insDatalist.appendChild(opt);
                });
            }

            var vehSelect = form.querySelector('#driveflow-vehicle-select');
            if (vehSelect && dir.vehicles) {
                vehSelect.innerHTML = '<option value="">-- Select Training Vehicle & Plate --</option>';
                dir.vehicles.forEach(function (v) {
                    var opt = document.createElement('option');
                    opt.value = v.plate_number;
                    opt.textContent = v.plate_number + (v.model ? ' (' + v.model + ')' : '');
                    vehSelect.appendChild(opt);
                });
            }
        }).catch(function () {
            var vehSelect = form.querySelector('#driveflow-vehicle-select');
            if (vehSelect) vehSelect.innerHTML = '<option value="">-- No vehicle selected --</option>';
        });

        function startCamera() {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                return setMessage(message, 'Camera access is not supported on this device/browser.', true);
            }
            if (stream) {
                stream.getTracks().forEach(function (t) { t.stop(); });
            }
            var constraints = {
                video: { facingMode: useFrontCamera ? 'user' : 'environment' },
                audio: false
            };
            navigator.mediaDevices.getUserMedia(constraints).then(function (activeStream) {
                stream = activeStream;
                video.srcObject = stream;
                video.style.display = 'block';
                if (preview) preview.style.display = 'none';
                captureButton.disabled = false;
                flipButton.disabled = false;
                cameraButton.textContent = 'Camera Active ✓';
                setMessage(message, 'Camera is active. Frame yourself and tap Capture Selfie.');
            }).catch(function (err) {
                setMessage(message, 'Camera access denied: ' + err.message, true);
            });
        }

        cameraButton.addEventListener('click', startCamera);

        flipButton.addEventListener('click', function () {
            useFrontCamera = !useFrontCamera;
            startCamera();
        });

        captureButton.addEventListener('click', function () {
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            var dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            selfieInput.value = dataUrl;

            if (preview) {
                preview.src = dataUrl;
                preview.style.display = 'block';
                video.style.display = 'none';
            }
            setMessage(message, 'Instructor selfie captured successfully ✓');
        });

        // Form Submit
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            var data = Object.fromEntries(new FormData(form).entries());
            data.session_number = Number(data.session_number) || 1;
            data.scheduled_start = data.scheduled_start.replace('T', ' ') + ':00';
            data.scheduled_end = data.scheduled_end.replace('T', ' ') + ':00';

            data.form_data = {
                source: 'instructor-form',
                captured_at: new Date().toISOString(),
                plate: data.plate_number || '',
                skills: {
                    clutch: parseInt(data.skill_clutch, 10) || 4,
                    parking: parseInt(data.skill_parking, 10) || 4,
                    steering: parseInt(data.skill_steering, 10) || 5,
                    rules: parseInt(data.skill_rules, 10) || 5
                },
                instructor_notes: data.instructor_notes || ''
            };

            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.querySelector('.submit-text').style.display = 'none';
                submitBtn.querySelector('.submit-spinner').style.display = 'inline';
            }

            function sendSessionPayload() {
                request('/sessions', { method: 'POST', body: JSON.stringify(data) }).then(function () {
                    setMessage(message, 'Session & scorecard recorded successfully! Confirmation emails dispatched ✓');
                    form.reset();
                    if (preview) preview.style.display = 'none';
                    if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
                }).catch(function (error) {
                    setMessage(message, error.message, true);
                }).finally(function () {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.querySelector('.submit-text').style.display = 'inline';
                        submitBtn.querySelector('.submit-spinner').style.display = 'none';
                    }
                });
            }

            // Optional GPS location
            if (form.querySelector('[data-geo-checkbox]') && form.querySelector('[data-geo-checkbox]').checked && navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function (pos) {
                    data.form_data.gps = { lat: pos.coords.latitude, lng: pos.coords.longitude };
                    sendSessionPayload();
                }, function () {
                    sendSessionPayload();
                }, { timeout: 4000 });
            } else {
                sendSessionPayload();
            }
        });

        initSignature(form);
        initTimer(form);
        initStarRatings(form);
    }

    // Audio Chime synthesizer via Web Audio API
    function playChime() {
        try {
            var AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            var ctx = new AudioContext();
            var osc = ctx.createOscillator();
            var gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.18);
            gain.gain.setValueAtTime(0.18, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.65);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.65);
        } catch (e) {}
    }

    // Speech synthesis voice announcement
    function announceVoice(text) {
        if (!window.speechSynthesis) return;
        try {
            window.speechSynthesis.cancel();
            var utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 0.95;
            utterance.pitch = 1.05;
            var voices = window.speechSynthesis.getVoices();
            for (var i = 0; i < voices.length; i++) {
                if (voices[i].lang && voices[i].lang.indexOf('en') === 0) {
                    utterance.voice = voices[i];
                    break;
                }
            }
            window.speechSynthesis.speak(utterance);
        } catch (e) {}
    }

    // TV Lobby Board Controller
    function initBoard(board) {
        var grid = board.querySelector('[data-session-list]');
        var message = board.querySelector('[data-board-message]');
        var clock = board.querySelector('[data-board-clock]');
        var dateDisplay = board.querySelector('[data-board-date]');
        var soundBtn = board.querySelector('[data-toggle-sound]');
        var speechBtn = board.querySelector('[data-toggle-speech]');
        var fsBtn = board.querySelector('[data-toggle-fullscreen]');

        var soundEnabled = true;
        var speechEnabled = false;
        var previousActiveIds = {};

        if (soundBtn) {
            soundBtn.addEventListener('click', function () {
                soundEnabled = !soundEnabled;
                soundBtn.textContent = soundEnabled ? '🔔' : '🔕';
                soundBtn.classList.toggle('is-active', soundEnabled);
                soundBtn.title = soundEnabled ? 'Chime sound is active' : 'Chime sound is muted';
            });
            soundBtn.classList.add('is-active');
        }

        if (speechBtn) {
            speechBtn.addEventListener('click', function () {
                speechEnabled = !speechEnabled;
                speechBtn.classList.toggle('is-active', speechEnabled);
                speechBtn.title = speechEnabled ? 'Voice announcer is active' : 'Voice announcer is muted';
                if (speechEnabled) {
                    announceVoice('Lobby voice announcer is now activated.');
                }
            });
        }

        if (fsBtn) {
            fsBtn.addEventListener('click', function () {
                if (!document.fullscreenElement) {
                    board.requestFullscreen ? board.requestFullscreen() : board.webkitRequestFullscreen();
                } else {
                    document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullscreen();
                }
            });
        }

        function tick() {
            var now = new Date();
            if (clock) {
                clock.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            }
            if (dateDisplay) {
                try {
                    dateDisplay.textContent = new Intl.DateTimeFormat('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(now);
                } catch (e) {
                    dateDisplay.textContent = now.toDateString();
                }
            }
        }

        function formatTimeStr(str) {
            if (!str) return '--:--';
            try {
                var d = new Date(str.replace(/-/g, '/'));
                if (isNaN(d.getTime())) return str.substring(11, 16);
                var h = d.getHours();
                var m = d.getMinutes();
                var ampm = h >= 12 ? 'PM' : 'AM';
                h = h % 12;
                h = h ? h : 12;
                m = m < 10 ? '0' + m : m;
                return h + ':' + m + ' ' + ampm;
            } catch (e) {
                return str.substring(11, 16);
            }
        }

        function render(sessions) {
            if (message) message.style.display = 'none';

            if (!sessions || !sessions.length) {
                grid.innerHTML =
                    '<div class="df-tv-standby-card">' +
                        '<div class="df-tv-standby-icon">🚗</div>' +
                        '<div class="df-tv-standby-badge">' +
                            '<span class="df-pulsing-dot-sm"></span> Training Fleet Active & On Standby' +
                        '</div>' +
                        '<h3 class="df-tv-standby-title">Certified Instructors & Dual-Control Vehicles Ready</h3>' +
                        '<p class="df-tv-standby-desc">' +
                            'Today\'s driving sessions will appear here live in real-time as instructors activate in-car evaluations and dispatch onto the road.' +
                        '</p>' +
                        '<div class="df-tv-standby-footer">' +
                            '<span class="df-standby-tag">🛡️ Dual-Control Safety Certified</span>' +
                            '<span class="df-standby-tag">🏛️ Maryland MVA / COMAR 11.23 Compliant</span>' +
                            '<span class="df-standby-tag">📍 Rockville, MD</span>' +
                        '</div>' +
                    '</div>';
                return;
            }

            grid.innerHTML = '';

            var newActiveIds = {};
            var newlyActiveSession = null;

            // Sort: active first, then upcoming, then completed
            var sorted = sessions.slice().sort(function (a, b) {
                var order = { 'active': 1, 'upcoming': 2, 'completed': 3 };
                var oa = order[a.status] || 4;
                var ob = order[b.status] || 4;
                if (oa !== ob) return oa - ob;
                return (a.scheduled_start || '').localeCompare(b.scheduled_start || '');
            });

            sorted.forEach(function (s) {
                var isActive = s.status === 'active';
                var isCompleted = s.status === 'completed';
                if (isActive) {
                    newActiveIds[s.id] = true;
                    if (!previousActiveIds[s.id]) {
                        newlyActiveSession = s;
                    }
                }

                var card = document.createElement('article');
                var cardClass = isActive ? 'is-active' : (isCompleted ? 'is-completed' : 'is-upcoming');
                var statusClass = isActive ? 'active' : (isCompleted ? 'completed' : 'upcoming');
                var statusText = isActive ? 'ACTIVE · ON ROAD' : (isCompleted ? 'COMPLETED' : 'UPCOMING NEXT');
                card.className = 'driveflow-tv-card ' + cardClass;

                var rawPlate = (s.plate_number || 'MVA-REG').toUpperCase().replace(/[^A-Z0-9\s\-]/g, '');
                var plate = rawPlate || 'MVA-REG';
                var startTime = formatTimeStr(s.scheduled_start);
                var endTime = formatTimeStr(s.scheduled_end);
                var studentName = s.student_name || 'Enrolled Student';
                var instructorName = s.instructor_name || 'Assigned Instructor';
                var topic = s.lesson_topic || 'Behind-The-Wheel Driving Lesson';
                var lessonNum = s.session_number || 1;

                card.innerHTML =
                    '<div class="df-card-top">' +
                        '<div class="maryland-plate plate-sm" title="Maryland Registration: ' + plate + '" data-plate="' + plate + '" role="button" tabindex="0">' +
                            '<span class="plate-bolt bolt-tl"></span><span class="plate-bolt bolt-tr"></span>' +
                            '<span class="plate-number">' + plate + '</span>' +
                            '<span class="plate-bolt bolt-bl"></span><span class="plate-bolt bolt-br"></span>' +
                            '<span class="plate-shine"></span>' +
                        '</div>' +
                        '<div class="df-card-status-badge ' + statusClass + '">' +
                            '<span class="df-pulsing-dot-sm"></span> ' + statusText +
                        '</div>' +
                    '</div>' +
                    '<div class="df-card-mid">' +
                        '<div class="df-card-student-wrap">' +
                            '<span class="df-student-avatar">🎓</span>' +
                            '<h3 class="df-card-student">' + studentName + '</h3>' +
                        '</div>' +
                        '<div class="df-card-meta-row">' +
                            '<span class="df-meta-pill instructor">👨‍🏫 ' + instructorName + '</span>' +
                            '<span class="df-meta-pill topic">🚗 Lesson ' + lessonNum + ' · ' + topic + '</span>' +
                        '</div>' +
                    '</div>' +
                    '<div class="df-card-time-bar">' +
                        '<span class="df-time-clock">🕒</span>' +
                        '<span class="df-time-range">' + startTime + ' – ' + endTime + '</span>' +
                    '</div>';

                grid.appendChild(card);
            });

            if (newlyActiveSession) {
                if (soundEnabled) playChime();
                if (speechEnabled) {
                    announceVoice('Driving session started for ' + newlyActiveSession.student_name + ' with instructor ' + (newlyActiveSession.instructor_name || 'unassigned') + '.');
                }
            }

            previousActiveIds = newActiveIds;
        }

        function refresh() {
            var ajaxUrl = config.ajaxurl || '/wp-admin/admin-ajax.php';
            var fetchUrl = ajaxUrl + '?action=driveflow_get_tv_sessions';

            fetch(fetchUrl, {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            })
            .then(function (res) { return res.json(); })
            .then(function (res) {
                if (res && res.success && Array.isArray(res.data)) {
                    render(res.data);
                } else if (Array.isArray(res)) {
                    render(res);
                } else {
                    fallbackRest();
                }
            })
            .catch(function () {
                fallbackRest();
            });

            function fallbackRest() {
                if (!config.tvApiUrl) return;
                fetch(config.tvApiUrl + (config.tvApiUrl.indexOf('?') >= 0 ? '&' : '?') + 'limit=50', {
                    headers: { 'X-DriveFlow-API-Key': config.tvApiKey || '', 'Accept': 'application/json' }
                })
                .then(function (res) { return res.json(); })
                .then(function (body) {
                    if (Array.isArray(body)) render(body);
                })
                .catch(function () {});
            }
        }

        tick();
        if (config.initialSessions && Array.isArray(config.initialSessions) && config.initialSessions.length) {
            render(config.initialSessions);
        } else {
            refresh();
        }
        window.setInterval(tick, 1000);
        window.setInterval(refresh, (Number(config.pollSeconds) || 15) * 1000);
    }

    document.querySelectorAll('[data-session-form]').forEach(initForm);
    document.querySelectorAll('[data-driveflow-board]').forEach(initBoard);

    // Global Maryland Plate Showcase Modal for Frontend
    document.addEventListener('click', function (e) {
        var plateEl = e.target.closest('.maryland-plate');
        if (!plateEl) return;
        var plateNum = plateEl.getAttribute('data-plate') || (plateEl.querySelector('.plate-number') ? plateEl.querySelector('.plate-number').textContent.trim() : '');
        if (!plateNum || plateNum === '—') return;

        var existing = document.getElementById('df-frontend-plate-modal');
        if (!existing) {
            var modalDiv = document.createElement('div');
            modalDiv.id = 'df-frontend-plate-modal';
            modalDiv.className = 'df-modal-backdrop';
            modalDiv.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(15,23,42,0.8);z-index:99999;display:none;align-items:center;justify-content:center;padding:16px;';
            modalDiv.innerHTML =
                '<div style="background:#fff;border-radius:16px;max-width:540px;width:100%;box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);overflow:hidden;font-family:sans-serif;direction:ltr;text-align:left;">' +
                    '<div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #e2e8f0;background:#f8fafc;">' +
                        '<h3 style="margin:0;font-size:16px;color:#0f172a;font-weight:700;">Maryland Vehicle Registration Showcase</h3>' +
                        '<button type="button" id="df-close-fe-modal" style="background:none;border:none;font-size:24px;cursor:pointer;color:#64748b;line-height:1;">&times;</button>' +
                    '</div>' +
                    '<div style="padding:24px;text-align:center;">' +
                        '<div class="df-plate-showcase-box" style="margin-bottom:18px;">' +
                            '<div class="maryland-plate plate-xl" id="df-fe-modal-plate">' +
                                '<span class="plate-bolt bolt-tl"></span><span class="plate-bolt bolt-tr"></span>' +
                                '<span class="plate-number" id="df-fe-modal-num"></span>' +
                                '<span class="plate-bolt bolt-bl"></span><span class="plate-bolt bolt-br"></span>' +
                                '<span class="plate-shine"></span>' +
                            '</div>' +
                            '<div class="df-plate-sticker-tag">DEC 26</div>' +
                        '</div>' +
                        '<div class="df-plate-info-grid" style="font-size:13px;margin-bottom:0;">' +
                            '<div class="df-plate-info-item"><label>Issuing State</label><span>State of Maryland (MVA)</span></div>' +
                            '<div class="df-plate-info-item"><label>Registration Class</label><span>Commercial Driver Training</span></div>' +
                            '<div class="df-plate-info-item"><label>Dual Brakes</label><span style="color:#16a34a;font-weight:700;">Certified & Verified</span></div>' +
                            '<div class="df-plate-info-item"><label>Active Status</label><span style="color:#16a34a;font-weight:700;">On Duty / In-Service</span></div>' +
                        '</div>' +
                    '</div>' +
                    '<div style="padding:14px 20px;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;">' +
                        '<button type="button" id="df-done-fe-modal" style="background:#0f766e;color:#fff;border:none;padding:8px 18px;border-radius:8px;font-weight:600;cursor:pointer;">Close</button>' +
                    '</div>' +
                '</div>';
            document.body.appendChild(modalDiv);
            existing = modalDiv;

            document.getElementById('df-close-fe-modal').addEventListener('click', function() { existing.style.display = 'none'; });
            document.getElementById('df-done-fe-modal').addEventListener('click', function() { existing.style.display = 'none'; });
            existing.addEventListener('click', function(ev) { if (ev.target === existing) existing.style.display = 'none'; });
        }

        document.getElementById('df-fe-modal-num').textContent = plateNum;
        existing.style.display = 'flex';
    });
})();
