<?php defined('ABSPATH') || exit; ?>
<div class="driveflow-app driveflow-tv" dir="ltr" data-driveflow-board>
    <header class="driveflow-header"><div class="driveflow-brand"><?php if ($brand['logo']) : ?><img src="<?php echo esc_url($brand['logo']); ?>" alt="<?php echo esc_attr($brand['name']); ?> logo"><?php endif; ?><strong><?php echo esc_html($brand['name']); ?></strong></div><time data-board-clock></time></header>
    <main class="driveflow-board-content"><h1>Session board</h1><p class="driveflow-message" data-board-message>Loading sessions...</p><div class="driveflow-session-list" data-session-list></div></main>
</div>
