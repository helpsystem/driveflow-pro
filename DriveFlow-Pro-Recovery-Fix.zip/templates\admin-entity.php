<?php defined('ABSPATH') || exit; ?>
<div class="wrap">
    <h1>DriveFlow Pro <?php echo esc_html($title); ?></h1>
    <?php if (!empty($_GET['added'])) : ?><div class="notice notice-success is-dismissible"><p>Record saved.</p></div><?php endif; ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="background:#fff;border:1px solid #ccd0d4;padding:16px;max-width:900px;margin:18px 0">
        <input type="hidden" name="action" value="driveflow_save_entity"><input type="hidden" name="entity" value="<?php echo esc_attr($entity); ?>"><?php wp_nonce_field('driveflow_save_entity'); ?>
        <h2>Add <?php echo esc_html(rtrim($title, 's')); ?></h2>
        <?php foreach ($fields as $label => $field) : ?><label style="display:inline-block;margin:0 10px 10px 0"><?php echo esc_html($label); ?><br><input required name="<?php echo esc_attr($field); ?>" type="<?php echo 'email' === $field ? 'email' : 'text'; ?>"></label><?php endforeach; ?>
        <br><button class="button button-primary">Save record</button>
    </form>
    <form method="get" style="margin:18px 0"><input type="hidden" name="page" value="driveflow-pro-<?php echo esc_attr($entity); ?>"><input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search records"><button class="button">Search</button></form>
    <table class="widefat striped"><thead><tr><th>ID</th><?php foreach ($fields as $label => $field) echo '<th>' . esc_html($label) . '</th>'; ?><th>Status</th></tr></thead><tbody>
    <?php if (!$rows) : ?><tr><td colspan="<?php echo esc_attr(count($fields) + 2); ?>">No records found.</td></tr><?php endif; ?>
    <?php foreach ($rows as $row) : ?><tr><td><?php echo esc_html($row['id']); ?></td><?php foreach ($fields as $field) echo '<td>' . esc_html($row[$field] ?? '') . '</td>'; ?><td><?php echo esc_html($row['status'] ?? ''); ?></td></tr><?php endforeach; ?>
    </tbody></table>
</div>
