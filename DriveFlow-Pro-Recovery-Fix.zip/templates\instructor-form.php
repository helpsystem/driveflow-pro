<?php defined('ABSPATH') || exit; ?>
<div class="driveflow-app driveflow-form" dir="ltr" data-driveflow-form>
    <header class="driveflow-header"><div class="driveflow-brand"><?php if ($brand['logo']) : ?><img src="<?php echo esc_url($brand['logo']); ?>" alt="<?php echo esc_attr($brand['name']); ?> logo"><?php endif; ?><strong><?php echo esc_html($brand['name']); ?></strong></div><span>DriveFlow Pro</span></header>
    <main class="driveflow-panel">
        <h1>Complete driving session</h1>
        <form data-session-form>
            <div class="driveflow-grid">
                <label>Student name<input name="student_name" list="driveflow-students" required maxlength="190" type="text"><datalist id="driveflow-students"></datalist></label>
                <label>Instructor name<input name="instructor_name" maxlength="190" type="text"></label>
                <label>Session number<input name="session_number" min="1" value="1" required type="number"></label>
                <label>Lesson topic<input name="lesson_topic" maxlength="190" type="text"></label>
                <label>Start time<input name="scheduled_start" required type="datetime-local"></label>
                <label>End time<input name="scheduled_end" required type="datetime-local"></label>
            </div>
            <section class="capture-block"><h2>Instructor selfie</h2><video data-camera autoplay muted playsinline></video><canvas data-selfie-canvas hidden></canvas><div class="driveflow-actions"><button type="button" class="driveflow-button" data-start-camera>Start camera</button><button type="button" class="driveflow-button" data-capture-selfie disabled>Capture photo</button></div><input type="hidden" name="selfie" data-selfie-input></section>
            <section class="capture-block"><h2>Signature</h2><canvas class="signature-canvas" data-signature-canvas></canvas><button type="button" class="driveflow-button" data-clear-signature>Clear signature</button><input type="hidden" name="signature" data-signature-input></section>
            <button class="driveflow-submit" type="submit">Save session</button><p class="driveflow-message" data-form-message role="status"></p>
        </form>
    </main>
</div>
