(function () {
    'use strict';
    var config = window.DriveFlowPro || {};

    function request(path, options) {
        options = options || {};
        options.headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
        if (config.nonce) options.headers['X-WP-Nonce'] = config.nonce;
        return fetch((config.root || '') + path, options).then(function (response) {
            return response.json().then(function (body) { if (!response.ok) throw new Error(body.message || 'Request failed.'); return body; });
        });
    }

    function setMessage(element, text, isError) {
        element.textContent = text;
        element.classList.toggle('is-error', Boolean(isError));
    }

    function initSignature(form) {
        var canvas = form.querySelector('[data-signature-canvas]');
        var input = form.querySelector('[data-signature-input]');
        var context = canvas.getContext('2d');
        var drawing = false;
        function resize() {
            var ratio = window.devicePixelRatio || 1;
            var width = canvas.clientWidth || 600;
            var height = canvas.clientHeight || 180;
            canvas.width = width * ratio; canvas.height = height * ratio;
            context.scale(ratio, ratio); context.strokeStyle = '#12332d'; context.lineWidth = 2; context.lineCap = 'round';
        }
        function point(event) { var rect = canvas.getBoundingClientRect(); return { x: event.clientX - rect.left, y: event.clientY - rect.top }; }
        canvas.addEventListener('pointerdown', function (event) { drawing = true; canvas.setPointerCapture(event.pointerId); var p = point(event); context.beginPath(); context.moveTo(p.x, p.y); });
        canvas.addEventListener('pointermove', function (event) { if (!drawing) return; var p = point(event); context.lineTo(p.x, p.y); context.stroke(); input.value = canvas.toDataURL('image/png'); });
        ['pointerup', 'pointercancel'].forEach(function (name) { canvas.addEventListener(name, function () { drawing = false; }); });
        form.querySelector('[data-clear-signature]').addEventListener('click', function () { context.clearRect(0, 0, canvas.width, canvas.height); input.value = ''; });
        resize(); window.addEventListener('resize', resize);
    }

    function initForm(form) {
        var video = form.querySelector('[data-camera]'); var canvas = form.querySelector('[data-selfie-canvas]');
        var selfieInput = form.querySelector('[data-selfie-input]'); var cameraButton = form.querySelector('[data-start-camera]');
        var captureButton = form.querySelector('[data-capture-selfie]'); var message = form.querySelector('[data-form-message]'); var stream;
        request('/directory').then(function (people) { var datalist = form.querySelector('#driveflow-students'); people.forEach(function (person) { var option = document.createElement('option'); option.value = person.student_name; datalist.appendChild(option); }); }).catch(function () { /* Directory suggestions are optional. */ });
        cameraButton.addEventListener('click', function () {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return setMessage(message, 'Camera access is unavailable in this browser.', true);
            navigator.mediaDevices.getUserMedia({ video: true, audio: false }).then(function (activeStream) { stream = activeStream; video.srcObject = stream; captureButton.disabled = false; cameraButton.textContent = 'Camera active'; }).catch(function () { setMessage(message, 'Camera permission was not granted.', true); });
        });
        captureButton.addEventListener('click', function () { canvas.width = video.videoWidth; canvas.height = video.videoHeight; canvas.getContext('2d').drawImage(video, 0, 0); selfieInput.value = canvas.toDataURL('image/jpeg', .82); setMessage(message, 'Selfie captured.'); });
        form.addEventListener('submit', function (event) {
            event.preventDefault(); var data = Object.fromEntries(new FormData(form).entries());
            data.session_number = Number(data.session_number); data.scheduled_start = data.scheduled_start.replace('T', ' ') + ':00'; data.scheduled_end = data.scheduled_end.replace('T', ' ') + ':00';
            data.form_data = { source: 'instructor-form', captured_at: new Date().toISOString() };
            request('/sessions', { method: 'POST', body: JSON.stringify(data) }).then(function () { setMessage(message, 'Session saved successfully.'); form.reset(); if (stream) stream.getTracks().forEach(function (track) { track.stop(); }); }).catch(function (error) { setMessage(message, error.message, true); });
        });
        initSignature(form);
    }

    function initBoard(board) {
        var list = board.querySelector('[data-session-list]'); var message = board.querySelector('[data-board-message]'); var clock = board.querySelector('[data-board-clock]');
        function tick() { clock.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
        function render(sessions) { message.textContent = sessions.length ? '' : 'No sessions scheduled.'; list.textContent = ''; sessions.forEach(function (session) { var row = document.createElement('article'); row.className = 'driveflow-session'; row.innerHTML = '<strong></strong><span></span><span></span><span></span>'; row.children[0].textContent = session.student_name; row.children[1].textContent = session.instructor_name || 'Instructor pending'; row.children[2].textContent = session.lesson_topic || 'Driving lesson'; row.children[3].textContent = new Date(session.scheduled_start.replace(' ', 'T')).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' · ' + session.status; list.appendChild(row); }); }
        function refresh() {
            var endpoint = config.tvApiUrl || ((config.root || '') + '/tv-sessions');
            request(endpoint.replace(config.root || '', '') + '?limit=50', { headers: { 'X-DriveFlow-API-Key': config.tvApiKey || '' } }).then(render).catch(function (error) { setMessage(message, error.message, true); });
        }
        tick(); refresh(); window.setInterval(tick, 1000); window.setInterval(refresh, (Number(config.pollSeconds) || 15) * 1000);
    }

    document.querySelectorAll('[data-session-form]').forEach(initForm);
    document.querySelectorAll('[data-driveflow-board]').forEach(initBoard);
}());
