<?php defined('ABSPATH') || exit; ?>
<div class="wrap">
    <h1>DriveFlow Pro Records</h1>
    <?php if (!empty($_GET['seeded'])) : ?><div class="notice notice-success is-dismissible"><p>Demo sessions were added.</p></div><?php endif; ?>
    <?php if (!empty($_GET['cleared'])) : ?><div class="notice notice-success is-dismissible"><p>Demo sessions were removed.</p></div><?php endif; ?>
    <p>Use this screen to test database reads and search before importing real school data.</p>
    <p>
        <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=driveflow_seed_demo'), 'driveflow_seed_demo')); ?>">Add demo data</a>
        <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=driveflow_clear_demo'), 'driveflow_clear_demo')); ?>">Remove demo data</a>
    </p>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="padding:16px;background:#fff;border:1px solid #ccd0d4;max-width:900px">
        <input type="hidden" name="action" value="driveflow_add_session"><?php wp_nonce_field('driveflow_add_session'); ?>
        <h2>Add a test session</h2>
        <p><input required name="student_name" placeholder="Student name"><input name="instructor_name" placeholder="Instructor name"><input min="1" type="number" name="session_number" value="1" placeholder="Session #"></p>
        <p><input name="lesson_topic" placeholder="Lesson topic"><input required type="datetime-local" name="scheduled_start"><input required type="datetime-local" name="scheduled_end"><select name="status"><option value="upcoming">Upcoming</option><option value="active">Active</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select> <button class="button button-primary">Save test session</button></p>
    </form>
    <form method="get" style="margin:20px 0">
        <input type="hidden" name="page" value="driveflow-pro-records">
        <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Search student, instructor, or topic">
        <button class="button">Search records</button>
    </form>
    <table class="widefat striped">
        <thead><tr><th>ID</th><th>Student</th><th>Instructor</th><th>Session</th><th>Topic</th><th>Start</th><th>Status</th></tr></thead>
        <tbody>
        <?php if (!$rows) : ?><tr><td colspan="7">No records found.</td></tr><?php endif; ?>
        <?php foreach ($rows as $row) : ?>
            <tr><td><?php echo esc_html($row['id']); ?></td><td><?php echo esc_html($row['student_name']); ?></td><td><?php echo esc_html($row['instructor_name']); ?></td><td><?php echo esc_html($row['session_number']); ?></td><td><?php echo esc_html($row['lesson_topic']); ?></td><td><?php echo esc_html($row['scheduled_start']); ?></td><td><?php echo esc_html($row['status']); ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
