(function ($) {
    $('#driveflow-upload-logo').on('click', function () {
        var frame = wp.media({ title: 'Select driving school logo', button: { text: 'Use this logo' }, multiple: false });
        frame.on('select', function () {
            var item = frame.state().get('selection').first().toJSON();
            $('#driveflow-logo-url').val(item.url);
            $('#driveflow-logo-preview').attr('src', item.url).show();
        });
        frame.open();
    });
}(jQuery));
