<?php
/**
 * Plugin Name: DriveFlow Pro
 * Description: Secure session management, instructor capture, and live lobby board for driving schools.
 * Version: 1.1.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: DriveFlow Pro
 * Text Domain: driveflow-pro
 */

defined('ABSPATH') || exit;

define('DRIVEFLOW_PRO_VERSION', '1.1.0');
define('DRIVEFLOW_PRO_FILE', __FILE__);
define('DRIVEFLOW_PRO_DIR', plugin_dir_path(__FILE__));
define('DRIVEFLOW_PRO_URL', plugin_dir_url(__FILE__));

final class DriveFlow_Pro {
    const OPTION_KEY = 'driveflow_pro_settings';
    const REST_NAMESPACE = 'driveflow/v1';

    public static function boot() {
        $plugin = new self();
        $settings = get_option(self::OPTION_KEY, array());
        if (empty($settings['tv_api_key'])) {
            $settings['tv_api_key'] = wp_generate_password(48, false, false);
            update_option(self::OPTION_KEY, $settings);
        }
        self::ensure_roles();
        add_action('admin_menu', array($plugin, 'admin_menu'));
        add_action('admin_post_driveflow_seed_demo', array($plugin, 'seed_demo_data'));
        add_action('admin_post_driveflow_clear_demo', array($plugin, 'clear_demo_data'));
        add_action('admin_post_driveflow_add_session', array($plugin, 'add_admin_session'));
        add_action('admin_post_driveflow_provision_pages', array($plugin, 'provision_pages_action'));
        add_action('admin_post_driveflow_save_entity', array($plugin, 'save_entity'));
        add_action('admin_init', array($plugin, 'register_settings'));
        add_action('admin_enqueue_scripts', array($plugin, 'admin_assets'));
        add_action('wp_enqueue_scripts', array($plugin, 'frontend_assets'));
        add_action('rest_api_init', array($plugin, 'register_routes'));
        add_shortcode('driveflow_instructor_form', array($plugin, 'instructor_form'));
        add_shortcode('driveflow_tv_board', array($plugin, 'tv_board'));
        $plugin->ensure_schema();
        $plugin->ensure_pages();
    }

    public static function activate() {
        self::ensure_roles();
        global $wpdb;
        $table = $wpdb->prefix . 'driveflow_sessions';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            student_name varchar(190) NOT NULL,
            instructor_name varchar(190) NOT NULL DEFAULT '',
            session_number smallint(5) unsigned NOT NULL DEFAULT 1,
            lesson_topic varchar(190) NOT NULL DEFAULT '',
            scheduled_start datetime NOT NULL,
            scheduled_end datetime NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'upcoming',
            form_data longtext NULL,
            signature longtext NULL,
            selfie longtext NULL,
            student_id bigint(20) unsigned NOT NULL DEFAULT 0,
            instructor_id bigint(20) unsigned NOT NULL DEFAULT 0,
            vehicle_id bigint(20) unsigned NOT NULL DEFAULT 0,
            plate_number varchar(50) NOT NULL DEFAULT '',
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY status_start (status, scheduled_start),
            KEY scheduled_start (scheduled_start)
        ) {$charset};";
        dbDelta($sql);
        dbDelta("CREATE TABLE {$wpdb->prefix}driveflow_students (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL, phone varchar(50) NOT NULL DEFAULT '', email varchar(190) NOT NULL DEFAULT '', license_number varchar(100) NOT NULL DEFAULT '', status varchar(20) NOT NULL DEFAULT 'active', created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), KEY name (name), KEY status (status)) {$charset};");
        dbDelta("CREATE TABLE {$wpdb->prefix}driveflow_instructors (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL, phone varchar(50) NOT NULL DEFAULT '', email varchar(190) NOT NULL DEFAULT '', license_number varchar(100) NOT NULL DEFAULT '', status varchar(20) NOT NULL DEFAULT 'active', created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), KEY name (name), KEY status (status)) {$charset};");
        dbDelta("CREATE TABLE {$wpdb->prefix}driveflow_vehicles (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, plate_number varchar(50) NOT NULL, model varchar(190) NOT NULL DEFAULT '', color varchar(50) NOT NULL DEFAULT '', status varchar(20) NOT NULL DEFAULT 'active', created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), KEY plate_number (plate_number), KEY status (status)) {$charset};");
        add_option(self::OPTION_KEY, array(
            'logo_url' => '',
            'school_name' => get_bloginfo('name'),
            'api_poll_seconds' => 15,
            'tv_api_key' => wp_generate_password(48, false, false),
            'instructor_page_id' => 0,
            'tv_page_id' => 0,
            'tv_page_password' => '',
        ));
        self::provision_pages();
    }

    private static function ensure_roles() {
        add_role('driveflow_instructor', 'DriveFlow Instructor', array('read' => true, 'edit_posts' => true, 'upload_files' => true));
        add_role('driveflow_student', 'DriveFlow Student', array('read' => true));
    }

    private static function provision_pages() {
        $settings = get_option(self::OPTION_KEY, array());
        $pages = array(
            'instructor_page_id' => array('title' => 'Instructor Session', 'content' => '[driveflow_instructor_form]'),
            'tv_page_id' => array('title' => 'DriveFlow TV Board', 'content' => '[driveflow_tv_board]'),
        );
        foreach ($pages as $key => $page) {
            $page_id = absint($settings[$key] ?? 0);
            if (!$page_id || 'trash' === get_post_status($page_id)) {
                $existing = get_page_by_title($page['title'], OBJECT, 'page');
                $page_id = $existing ? $existing->ID : wp_insert_post(array('post_title' => $page['title'], 'post_content' => $page['content'], 'post_status' => 'publish', 'post_type' => 'page'), true);
            }
            if (!is_wp_error($page_id) && $page_id) {
                $settings[$key] = (int) $page_id;
                $post = get_post($page_id);
                if ($post && !has_shortcode((string) $post->post_content, $key === 'tv_page_id' ? 'driveflow_tv_board' : 'driveflow_instructor_form')) {
                    wp_update_post(array('ID' => $page_id, 'post_content' => trim($post->post_content . "\n\n" . $page['content'])));
                }
                if ('tv_page_id' === $key && !empty($settings['tv_page_password'])) {
                    wp_update_post(array('ID' => $page_id, 'post_password' => $settings['tv_page_password']));
                }
            }
        }
        update_option(self::OPTION_KEY, $settings);
    }

    private function ensure_pages() {
        self::provision_pages();
    }

    private function ensure_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'driveflow_sessions';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            student_name varchar(190) NOT NULL,
            instructor_name varchar(190) NOT NULL DEFAULT '',
            session_number smallint(5) unsigned NOT NULL DEFAULT 1,
            lesson_topic varchar(190) NOT NULL DEFAULT '',
            scheduled_start datetime NOT NULL,
            scheduled_end datetime NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'upcoming',
            form_data longtext NULL,
            signature longtext NULL,
            selfie longtext NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id), KEY status_start (status, scheduled_start), KEY scheduled_start (scheduled_start)
        ) {$charset};";
        dbDelta($sql);
    }

    public function admin_menu() {
        add_menu_page('DriveFlow Pro', 'DriveFlow Pro', 'manage_options', 'driveflow-pro', array($this, 'settings_page'), 'dashicons-car', 26);
        add_submenu_page('driveflow-pro', 'Dashboard', 'Dashboard', 'manage_options', 'driveflow-pro-dashboard', array($this, 'dashboard_page'));
        add_submenu_page('driveflow-pro', 'Students', 'Students', 'manage_options', 'driveflow-pro-students', array($this, 'people_page'));
        add_submenu_page('driveflow-pro', 'Instructors', 'Instructors', 'manage_options', 'driveflow-pro-instructors', array($this, 'people_page'));
        add_submenu_page('driveflow-pro', 'Vehicles', 'Vehicles', 'manage_options', 'driveflow-pro-vehicles', array($this, 'vehicles_page'));
        add_submenu_page('driveflow-pro', 'Reports', 'Reports', 'manage_options', 'driveflow-pro-reports', array($this, 'reports_page'));
        add_submenu_page('driveflow-pro', 'Records', 'Records', 'manage_options', 'driveflow-pro-records', array($this, 'records_page'));
    }

    public function register_settings() {
        register_setting('driveflow_pro_settings_group', self::OPTION_KEY, array($this, 'sanitize_settings'));
        add_settings_section('driveflow_general', 'General settings', '__return_false', 'driveflow-pro');
        add_settings_field('school_name', 'School name', array($this, 'text_field'), 'driveflow-pro', 'driveflow_general', array('key' => 'school_name', 'type' => 'text'));
        add_settings_field('logo_url', 'Driving school logo', array($this, 'logo_field'), 'driveflow-pro', 'driveflow_general');
        add_settings_field('api_poll_seconds', 'TV refresh interval (seconds)', array($this, 'text_field'), 'driveflow-pro', 'driveflow_general', array('key' => 'api_poll_seconds', 'type' => 'number'));
        add_settings_field('tv_api_key', 'TV API key', array($this, 'api_key_field'), 'driveflow-pro', 'driveflow_general');
        add_settings_field('tv_page_password', 'TV page password', array($this, 'text_field'), 'driveflow-pro', 'driveflow_general', array('key' => 'tv_page_password', 'type' => 'password'));
    }

    public function sanitize_settings($input) {
        $old = get_option(self::OPTION_KEY, array());
        $api_key = sanitize_text_field($input['tv_api_key'] ?? ($old['tv_api_key'] ?? ''));
        return array(
            'school_name' => sanitize_text_field($input['school_name'] ?? ($old['school_name'] ?? '')),
            'logo_url' => esc_url_raw($input['logo_url'] ?? ($old['logo_url'] ?? '')),
            'api_poll_seconds' => max(5, min(300, absint($input['api_poll_seconds'] ?? 15))),
            'tv_api_key' => $api_key ?: wp_generate_password(48, false, false),
            'tv_page_password' => sanitize_text_field($input['tv_page_password'] ?? ($old['tv_page_password'] ?? '')),
        );
    }

    public function text_field($args) {
        $settings = get_option(self::OPTION_KEY, array());
        $key = $args['key'];
        printf('<input class="regular-text" name="%1$s[%2$s]" type="%3$s" value="%4$s" />', esc_attr(self::OPTION_KEY), esc_attr($key), esc_attr($args['type']), esc_attr($settings[$key] ?? ''));
    }

    public function logo_field() {
        $settings = get_option(self::OPTION_KEY, array());
        $url = esc_url($settings['logo_url'] ?? '');
        echo '<input id="driveflow-logo-url" class="regular-text" name="' . esc_attr(self::OPTION_KEY) . '[logo_url]" type="url" value="' . esc_attr($url) . '" />';
        echo ' <button type="button" class="button" id="driveflow-upload-logo">Select logo</button>';
        echo '<p><img id="driveflow-logo-preview" src="' . $url . '" alt="" style="max-width:180px;max-height:120px;margin-top:12px;' . ($url ? '' : 'display:none;') . '" /></p>';
    }

    public function api_key_field() {
        $settings = get_option(self::OPTION_KEY, array());
        echo '<input class="regular-text code" name="' . esc_attr(self::OPTION_KEY) . '[tv_api_key]" type="text" value="' . esc_attr($settings['tv_api_key'] ?? '') . '" autocomplete="off" />';
        echo '<p class="description">The key is sent to the protected TV endpoint. Regenerate it if the TV page URL or browser session is exposed.</p>';
    }

    public function admin_assets($hook) {
        if ('toplevel_page_driveflow-pro' !== $hook) return;
        wp_enqueue_media();
        wp_enqueue_script('driveflow-admin', DRIVEFLOW_PRO_URL . 'assets/admin.js', array('jquery'), DRIVEFLOW_PRO_VERSION, true);
    }

    public function frontend_assets() {
        wp_enqueue_style('driveflow-pro-font', 'https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;600;700;800&display=swap', array(), null);
        wp_enqueue_style('driveflow-pro', DRIVEFLOW_PRO_URL . 'assets/frontend.css', array(), DRIVEFLOW_PRO_VERSION);
        wp_enqueue_script('driveflow-pro', DRIVEFLOW_PRO_URL . 'assets/frontend.js', array(), DRIVEFLOW_PRO_VERSION, true);
        $settings = get_option(self::OPTION_KEY, array());
        wp_localize_script('driveflow-pro', 'DriveFlowPro', array(
            'root' => esc_url_raw(rest_url(self::REST_NAMESPACE)),
            'nonce' => wp_create_nonce('wp_rest'),
            'pollSeconds' => max(5, absint($settings['api_poll_seconds'] ?? 15)),
        ));
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $settings = get_option(self::OPTION_KEY, array());
        $health = $this->health_check();
        echo '<div class="wrap driveflow-admin"><h1>DriveFlow Pro</h1><p>Configure branding and lobby board behavior.</p><form method="post" action="options.php">';
        settings_fields('driveflow_pro_settings_group');
        do_settings_sections('driveflow-pro');
        submit_button('Save configuration');
        echo '</form><p>Instructor page: ' . (!empty($settings['instructor_page_id']) ? '<a href="' . esc_url(get_permalink($settings['instructor_page_id'])) . '" target="_blank">Open page</a>' : 'Not created') . ' | TV page: ' . (!empty($settings['tv_page_id']) ? '<a href="' . esc_url(get_permalink($settings['tv_page_id'])) . '" target="_blank">Open page</a>' : 'Not created') . '</p><hr><h2>System connection</h2><table class="widefat striped" style="max-width:900px"><tbody>';
        foreach ($health as $label => $ok) echo '<tr><td>' . esc_html($label) . '</td><td>' . ($ok ? '<span style="color:#16823b">OK</span>' : '<span style="color:#b32d2e">Needs attention</span>') . '</td></tr>';
        echo '</tbody></table><p><a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=driveflow_provision_pages'), 'driveflow_provision_pages')) . '">Check and create missing pages</a></p></div>';
    }

    private function health_check() {
        global $wpdb;
        $settings = get_option(self::OPTION_KEY, array());
        return array(
            'Database table' => (bool) $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $this->table())),
            'Instructor shortcode page' => !empty($settings['instructor_page_id']) && 'publish' === get_post_status($settings['instructor_page_id']) && has_shortcode((string) get_post_field('post_content', $settings['instructor_page_id']), 'driveflow_instructor_form'),
            'TV board shortcode page' => !empty($settings['tv_page_id']) && 'publish' === get_post_status($settings['tv_page_id']) && has_shortcode((string) get_post_field('post_content', $settings['tv_page_id']), 'driveflow_tv_board'),
            'TV API key' => !empty($settings['tv_api_key']),
            'REST API' => function_exists('rest_url'),
            'Frontend assets' => file_exists(DRIVEFLOW_PRO_DIR . 'assets/frontend.js') && file_exists(DRIVEFLOW_PRO_DIR . 'assets/frontend.css'),
        );
    }

    public function provision_pages_action() {
        if (!current_user_can('manage_options') || !check_admin_referer('driveflow_provision_pages')) wp_die('Unauthorized request.');
        self::provision_pages();
        wp_safe_redirect(admin_url('admin.php?page=driveflow-pro&pages_ready=1')); exit;
    }

    public function records_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;
        $search = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));
        $where = '';
        $args = array();
        if ($search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where = ' WHERE student_name LIKE %s OR instructor_name LIKE %s OR lesson_topic LIKE %s';
            $args = array($like, $like, $like);
        }
        $query = "SELECT id, student_name, instructor_name, session_number, lesson_topic, scheduled_start, status FROM {$this->table()}{$where} ORDER BY scheduled_start DESC LIMIT 100";
        $rows = $args ? $wpdb->get_results($wpdb->prepare($query, $args), ARRAY_A) : $wpdb->get_results($query, ARRAY_A);
        include DRIVEFLOW_PRO_DIR . 'templates/admin-records.php';
    }

    public function dashboard_page() {
        global $wpdb;
        $this->render_entity_page('Dashboard', 'driveflow_sessions', array('Total sessions' => 'COUNT(*)', 'Upcoming' => "SUM(status = 'upcoming')", 'Active' => "SUM(status = 'active')", 'Completed' => "SUM(status = 'completed')"), 'dashboard');
    }

    public function people_page() {
        $slug = sanitize_key($_GET['page'] ?? 'driveflow-pro-students');
        $entity = 'driveflow-pro-instructors' === $slug ? 'instructors' : 'students';
        $config = 'students' === $entity ? array('Name' => 'name', 'Phone' => 'phone', 'Email' => 'email', 'License number' => 'license_number') : array('Name' => 'name', 'Phone' => 'phone', 'Email' => 'email', 'Instructor license' => 'license_number');
        $this->render_entity_page(ucfirst($entity), 'driveflow_' . $entity, $config, $entity);
    }

    public function vehicles_page() {
        $this->render_entity_page('Vehicles', 'driveflow_vehicles', array('Plate number' => 'plate_number', 'Model' => 'model', 'Color' => 'color'), 'vehicles');
    }

    public function reports_page() {
        global $wpdb;
        $counts = $wpdb->get_results("SELECT status, COUNT(*) total FROM {$this->table()} GROUP BY status", ARRAY_A);
        echo '<div class="wrap"><h1>DriveFlow Pro Reports</h1><p>Live totals read from the DriveFlow database.</p><table class="widefat striped" style="max-width:600px"><thead><tr><th>Status</th><th>Total</th></tr></thead><tbody>';
        foreach ($counts as $count) echo '<tr><td>' . esc_html(ucfirst($count['status'])) . '</td><td>' . esc_html($count['total']) . '</td></tr>';
        if (!$counts) echo '<tr><td colspan="2">No sessions found.</td></tr>';
        echo '</tbody></table></div>';
    }

    private function render_entity_page($title, $table, $fields, $entity) {
        if (!current_user_can('manage_options')) return;
        global $wpdb;
        if ('dashboard' === $entity) {
            $stats = $wpdb->get_row("SELECT {$fields['Total sessions']} total, {$fields['Upcoming']} upcoming, {$fields['Active']} active, {$fields['Completed']} completed FROM {$this->table()}", ARRAY_A);
            echo '<div class="wrap"><h1>DriveFlow Pro Dashboard</h1><div style="display:flex;gap:16px;flex-wrap:wrap">';
            foreach ($stats as $label => $value) echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:20px;min-width:150px"><strong>' . esc_html(ucfirst($label)) . '</strong><br><span style="font-size:28px">' . esc_html($value) . '</span></div>';
            echo '</div></div>'; return;
        }
        $search = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));
        $search_like = '%' . $wpdb->esc_like($search) . '%';
        $where = $search ? ('vehicles' === $entity ? $wpdb->prepare(' WHERE plate_number LIKE %s OR model LIKE %s OR color LIKE %s', $search_like, $search_like, $search_like) : $wpdb->prepare(' WHERE name LIKE %s OR phone LIKE %s OR email LIKE %s', $search_like, $search_like, $search_like)) : '';
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}{$table}{$where} ORDER BY id DESC LIMIT 100", ARRAY_A);
        include DRIVEFLOW_PRO_DIR . 'templates/admin-entity.php';
    }

    public function save_entity() {
        if (!current_user_can('manage_options') || !check_admin_referer('driveflow_save_entity')) wp_die('Unauthorized request.');
        global $wpdb;
        $entity = sanitize_key($_POST['entity'] ?? '');
        $allowed = array('students' => 'students', 'instructors' => 'instructors', 'vehicles' => 'vehicles');
        if (!isset($allowed[$entity])) wp_die('Invalid entity.');
        $now = current_time('mysql');
        $data = array('created_at' => $now, 'updated_at' => $now, 'status' => 'active');
        if ('vehicles' === $entity) { $data['plate_number'] = sanitize_text_field(wp_unslash($_POST['plate_number'] ?? '')); $data['model'] = sanitize_text_field(wp_unslash($_POST['model'] ?? '')); $data['color'] = sanitize_text_field(wp_unslash($_POST['color'] ?? '')); }
        else { $data['name'] = sanitize_text_field(wp_unslash($_POST['name'] ?? '')); $data['phone'] = sanitize_text_field(wp_unslash($_POST['phone'] ?? '')); $data['email'] = sanitize_email(wp_unslash($_POST['email'] ?? '')); $data['license_number'] = sanitize_text_field(wp_unslash($_POST['license_number'] ?? '')); }
        if (!empty($data['name']) || !empty($data['plate_number'])) $wpdb->insert($wpdb->prefix . 'driveflow_' . $allowed[$entity], $data, array_fill(0, count($data), '%s'));
        wp_safe_redirect(admin_url('admin.php?page=driveflow-pro-' . $entity . '&added=1')); exit;
    }

    public function seed_demo_data() {
        if (!current_user_can('manage_options') || !check_admin_referer('driveflow_seed_demo')) wp_die('Unauthorized request.');
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->insert($wpdb->prefix . 'driveflow_students', array('name' => 'Ali Demo', 'phone' => '555-0101', 'email' => 'ali@example.test', 'license_number' => 'DEMO-ST-01', 'status' => 'active', 'created_at' => $now, 'updated_at' => $now), array('%s','%s','%s','%s','%s','%s','%s'));
        $wpdb->insert($wpdb->prefix . 'driveflow_students', array('name' => 'Mina Test', 'phone' => '555-0102', 'email' => 'mina@example.test', 'license_number' => 'DEMO-ST-02', 'status' => 'active', 'created_at' => $now, 'updated_at' => $now), array('%s','%s','%s','%s','%s','%s','%s'));
        $wpdb->insert($wpdb->prefix . 'driveflow_instructors', array('name' => 'Sara Instructor', 'phone' => '555-0201', 'email' => 'sara@example.test', 'license_number' => 'DEMO-IN-01', 'status' => 'active', 'created_at' => $now, 'updated_at' => $now), array('%s','%s','%s','%s','%s','%s','%s'));
        $wpdb->insert($wpdb->prefix . 'driveflow_vehicles', array('plate_number' => 'DF-TEST-01', 'model' => 'Test Vehicle', 'color' => 'Green', 'status' => 'active', 'created_at' => $now, 'updated_at' => $now), array('%s','%s','%s','%s','%s','%s'));
        $samples = array(
            array('Ali Demo', 'Sara Instructor', 1, 'Vehicle controls', 'upcoming'),
            array('Mina Test', 'Reza Instructor', 4, 'Parallel parking', 'active'),
            array('Nima Sample', 'Sara Instructor', 2, 'Reverse driving', 'completed'),
        );
        foreach ($samples as $sample) {
            $wpdb->insert($this->table(), array(
                'student_name' => $sample[0], 'instructor_name' => $sample[1], 'session_number' => $sample[2],
                'lesson_topic' => $sample[3], 'scheduled_start' => $now, 'scheduled_end' => $now,
                'status' => $sample[4], 'form_data' => wp_json_encode(array('demo' => true)),
                'signature' => '', 'selfie' => '', 'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
            ), array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s'));
        }
        wp_safe_redirect(admin_url('admin.php?page=driveflow-pro-records&seeded=1')); exit;
    }

    public function clear_demo_data() {
        if (!current_user_can('manage_options') || !check_admin_referer('driveflow_clear_demo')) wp_die('Unauthorized request.');
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$this->table()} WHERE form_data = %s", wp_json_encode(array('demo' => true))));
        $wpdb->query("DELETE FROM {$wpdb->prefix}driveflow_students WHERE license_number LIKE 'DEMO-ST-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}driveflow_instructors WHERE license_number LIKE 'DEMO-IN-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}driveflow_vehicles WHERE plate_number = 'DF-TEST-01'");
        wp_safe_redirect(admin_url('admin.php?page=driveflow-pro-records&cleared=1')); exit;
    }

    public function add_admin_session() {
        if (!current_user_can('manage_options') || !check_admin_referer('driveflow_add_session')) wp_die('Unauthorized request.');
        global $wpdb;
        $now = current_time('mysql');
        $student = sanitize_text_field(wp_unslash($_POST['student_name'] ?? ''));
        if ($student) {
            $wpdb->insert($this->table(), array(
                'student_name' => $student,
                'instructor_name' => sanitize_text_field(wp_unslash($_POST['instructor_name'] ?? '')),
                'session_number' => max(1, absint($_POST['session_number'] ?? 1)),
                'lesson_topic' => sanitize_text_field(wp_unslash($_POST['lesson_topic'] ?? '')),
                'scheduled_start' => $this->normalize_datetime(wp_unslash($_POST['scheduled_start'] ?? ''), $now),
                'scheduled_end' => $this->normalize_datetime(wp_unslash($_POST['scheduled_end'] ?? ''), $now),
                'status' => in_array($_POST['status'] ?? '', array('upcoming','active','completed','cancelled'), true) ? sanitize_key($_POST['status']) : 'upcoming',
                'form_data' => wp_json_encode(array('source' => 'admin')),
                'signature' => '', 'selfie' => '', 'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
            ), array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s'));
        }
        wp_safe_redirect(admin_url('admin.php?page=driveflow-pro-records&added=1')); exit;
    }

    private function normalize_datetime($value, $fallback) {
        $value = str_replace('T', ' ', sanitize_text_field($value));
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $value)) {
            return strlen($value) === 16 ? $value . ':00' : $value;
        }
        return $fallback;
    }

    private function branding() {
        $settings = get_option(self::OPTION_KEY, array());
        return array('name' => sanitize_text_field($settings['school_name'] ?? get_bloginfo('name')), 'logo' => esc_url($settings['logo_url'] ?? ''));
    }

    public function instructor_form() {
        $brand = $this->branding();
        ob_start();
        include DRIVEFLOW_PRO_DIR . 'templates/instructor-form.php';
        return ob_get_clean();
    }

    public function tv_board() {
        $brand = $this->branding();
        $settings = get_option(self::OPTION_KEY, array());
        wp_add_inline_script('driveflow-pro', 'window.DriveFlowPro = Object.assign(window.DriveFlowPro || {}, ' . wp_json_encode(array(
            'tvApiUrl' => esc_url_raw(rest_url(self::REST_NAMESPACE . '/tv-sessions')),
            'tvApiKey' => sanitize_text_field($settings['tv_api_key'] ?? ''),
        )) . ');', 'after');
        ob_start();
        include DRIVEFLOW_PRO_DIR . 'templates/tv-board.php';
        return ob_get_clean();
    }

    public function register_routes() {
        register_rest_route(self::REST_NAMESPACE, '/sessions', array(
            array('methods' => WP_REST_Server::READABLE, 'callback' => array($this, 'get_sessions'), 'permission_callback' => array($this, 'can_write')),
            array('methods' => WP_REST_Server::CREATABLE, 'callback' => array($this, 'create_session'), 'permission_callback' => array($this, 'can_write')),
        ));
        register_rest_route(self::REST_NAMESPACE, '/tv-sessions', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_tv_sessions'),
            'permission_callback' => array($this, 'can_read_tv'),
        ));
        register_rest_route(self::REST_NAMESPACE, '/directory', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_directory'),
            'permission_callback' => array($this, 'can_write'),
        ));
        register_rest_route(self::REST_NAMESPACE, '/sessions/(?P<id>\d+)', array(
            array('methods' => WP_REST_Server::EDITABLE, 'callback' => array($this, 'update_session'), 'permission_callback' => array($this, 'can_write')),
            array('methods' => WP_REST_Server::DELETABLE, 'callback' => array($this, 'delete_session'), 'permission_callback' => array($this, 'can_delete')),
        ));
    }

    public function can_write($request) { return is_user_logged_in() && current_user_can('edit_posts') && wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest'); }
    public function can_delete($request) { return current_user_can('manage_options') && wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest'); }

    public function can_read_tv($request) {
        $settings = get_option(self::OPTION_KEY, array());
        $client_key = (string) $request->get_header('X-DriveFlow-API-Key');
        $server_key = (string) ($settings['tv_api_key'] ?? '');
        return $server_key && $client_key && hash_equals($server_key, $client_key)
            ? true
            : new WP_Error('rest_forbidden', 'Invalid TV API key.', array('status' => 403));
    }

    private function table() { global $wpdb; return $wpdb->prefix . 'driveflow_sessions'; }
    private function clean_session($params, $existing = array()) {
        $start = sanitize_text_field($params['scheduled_start'] ?? ($existing['scheduled_start'] ?? current_time('mysql')));
        $end = sanitize_text_field($params['scheduled_end'] ?? ($existing['scheduled_end'] ?? $start));
        $status = sanitize_key($params['status'] ?? ($existing['status'] ?? 'upcoming'));
        if (!in_array($status, array('upcoming', 'active', 'completed', 'cancelled'), true)) $status = 'upcoming';
        $form_data = $params['form_data'] ?? ($existing['form_data'] ?? array());
        if (is_string($form_data)) $form_data = json_decode(wp_unslash($form_data), true);
        $signature = sanitize_textarea_field($params['signature'] ?? ($existing['signature'] ?? ''));
        $selfie = sanitize_textarea_field($params['selfie'] ?? ($existing['selfie'] ?? ''));
        if (strlen($signature) > 2000000) $signature = '';
        if (strlen($selfie) > 5000000) $selfie = '';
        return array(
            'student_name' => sanitize_text_field($params['student_name'] ?? ($existing['student_name'] ?? '')),
            'instructor_name' => sanitize_text_field($params['instructor_name'] ?? ($existing['instructor_name'] ?? '')),
            'session_number' => max(1, absint($params['session_number'] ?? ($existing['session_number'] ?? 1))),
            'lesson_topic' => sanitize_text_field($params['lesson_topic'] ?? ($existing['lesson_topic'] ?? '')),
            'scheduled_start' => preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $start) ? $start : current_time('mysql'),
            'scheduled_end' => preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $end) ? $end : current_time('mysql'),
            'status' => $status,
            'form_data' => wp_json_encode(is_array($form_data) ? $form_data : array()),
            'signature' => $signature,
            'selfie' => $selfie,
        );
    }

    public function get_sessions($request) {
        global $wpdb;
        $limit = min(100, max(1, absint($request->get_param('limit') ?: 50)));
        $status = sanitize_key($request->get_param('status'));
        $where = $status ? $wpdb->prepare(' WHERE status = %s', $status) : '';
        $rows = $wpdb->get_results("SELECT id, student_name, instructor_name, session_number, lesson_topic, scheduled_start, scheduled_end, status, form_data, created_at, updated_at FROM {$this->table()}{$where} ORDER BY scheduled_start ASC LIMIT {$limit}", ARRAY_A);
        foreach ($rows as &$row) $row['form_data'] = json_decode($row['form_data'] ?: '{}', true);
        return rest_ensure_response($rows);
    }

    public function get_tv_sessions($request) {
        global $wpdb;
        $limit = min(50, max(1, absint($request->get_param('limit') ?: 25)));
        $rows = $wpdb->get_results("SELECT id, student_name, instructor_name, session_number, lesson_topic, scheduled_start, scheduled_end, status FROM {$this->table()} WHERE status IN ('upcoming', 'active') ORDER BY scheduled_start ASC LIMIT {$limit}", ARRAY_A);
        return rest_ensure_response($rows);
    }

    public function get_directory($request) {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT name AS student_name, '' AS instructor_name FROM {$wpdb->prefix}driveflow_students WHERE status = 'active' ORDER BY name ASC LIMIT 200", ARRAY_A);
        return rest_ensure_response($rows);
    }

    public function create_session($request) {
        global $wpdb;
        $data = $this->clean_session($request->get_json_params() ?: array());
        if (!$data['student_name']) return new WP_Error('missing_student', 'Student name is required.', array('status' => 400));
        $now = current_time('mysql');
        $data['created_by'] = get_current_user_id(); $data['created_at'] = $now; $data['updated_at'] = $now;
        $formats = array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s');
        $wpdb->insert($this->table(), $data, $formats);
        if (!$wpdb->insert_id) return new WP_Error('db_insert_failed', 'Session could not be saved.', array('status' => 500));
        return new WP_REST_Response(array('id' => (int) $wpdb->insert_id), 201);
    }

    public function update_session($request) {
        global $wpdb;
        $id = absint($request['id']);
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id = %d", $id), ARRAY_A);
        if (!$existing) return new WP_Error('not_found', 'Session not found.', array('status' => 404));
        $data = $this->clean_session($request->get_json_params() ?: array(), $existing); $data['updated_at'] = current_time('mysql');
        $wpdb->update($this->table(), $data, array('id' => $id), array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s'), array('%d'));
        return rest_ensure_response(array('id' => $id, 'updated' => true));
    }

    public function delete_session($request) {
        global $wpdb; $id = absint($request['id']);
        $deleted = $wpdb->delete($this->table(), array('id' => $id), array('%d'));
        return $deleted ? rest_ensure_response(array('deleted' => true)) : new WP_Error('not_found', 'Session not found.', array('status' => 404));
    }
}

register_activation_hook(DRIVEFLOW_PRO_FILE, array('DriveFlow_Pro', 'activate'));
add_action('plugins_loaded', array('DriveFlow_Pro', 'boot'));
