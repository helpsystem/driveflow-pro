<?php
/**
 * Plugin Name: DriveFlow Pro
 * Description: Secure session management, instructor capture, and live lobby board for driving schools.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: DriveFlow Pro
 * Text Domain: driveflow-pro
 */

defined('ABSPATH') || exit;

define('DRIVEFLOW_PRO_VERSION', '1.0.0');
define('DRIVEFLOW_PRO_FILE', __FILE__);
define('DRIVEFLOW_PRO_DIR', plugin_dir_path(__FILE__));
define('DRIVEFLOW_PRO_URL', plugin_dir_url(__FILE__));

final class DriveFlow_Pro {
    const OPTION_KEY = 'driveflow_pro_settings';
    const REST_NAMESPACE = 'driveflow/v1';

    public static function boot() {
        $plugin = new self();
        $settings = get_option(self::OPTION_KEY, array());
        if (empty($settings['tv_api_key'])) {
            $settings['tv_api_key'] = wp_generate_password(48, false, false);
            update_option(self::OPTION_KEY, $settings);
        }
        add_action('admin_menu', array($plugin, 'admin_menu'));
        add_action('admin_init', array($plugin, 'register_settings'));
        add_action('admin_enqueue_scripts', array($plugin, 'admin_assets'));
        add_action('wp_enqueue_scripts', array($plugin, 'frontend_assets'));
        add_action('rest_api_init', array($plugin, 'register_routes'));
        add_shortcode('driveflow_instructor_form', array($plugin, 'instructor_form'));
        add_shortcode('driveflow_tv_board', array($plugin, 'tv_board'));
    }

    public static function activate() {
        global $wpdb;
        $table = $wpdb->prefix . 'driveflow_sessions';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            student_name varchar(190) NOT NULL,
            instructor_name varchar(190) NOT NULL DEFAULT '',
            session_number smallint(5) unsigned NOT NULL DEFAULT 1,
            lesson_topic varchar(190) NOT NULL DEFAULT '',
            scheduled_start datetime NOT NULL,
            scheduled_end datetime NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'upcoming',
            form_data longtext NULL,
            signature longtext NULL,
            selfie longtext NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY status_start (status, scheduled_start),
            KEY scheduled_start (scheduled_start)
        ) {$charset};";
        dbDelta($sql);
        add_option(self::OPTION_KEY, array(
            'logo_url' => '',
            'school_name' => get_bloginfo('name'),
            'api_poll_seconds' => 15,
            'tv_api_key' => wp_generate_password(48, false, false),
        ));
    }

    public function admin_menu() {
        add_menu_page('DriveFlow Pro', 'DriveFlow Pro', 'manage_options', 'driveflow-pro', array($this, 'settings_page'), 'dashicons-car', 26);
    }

    public function register_settings() {
        register_setting('driveflow_pro_settings_group', self::OPTION_KEY, array($this, 'sanitize_settings'));
        add_settings_section('driveflow_general', 'General settings', '__return_false', 'driveflow-pro');
        add_settings_field('school_name', 'School name', array($this, 'text_field'), 'driveflow-pro', 'driveflow_general', array('key' => 'school_name', 'type' => 'text'));
        add_settings_field('logo_url', 'Driving school logo', array($this, 'logo_field'), 'driveflow-pro', 'driveflow_general');
        add_settings_field('api_poll_seconds', 'TV refresh interval (seconds)', array($this, 'text_field'), 'driveflow-pro', 'driveflow_general', array('key' => 'api_poll_seconds', 'type' => 'number'));
        add_settings_field('tv_api_key', 'TV API key', array($this, 'api_key_field'), 'driveflow-pro', 'driveflow_general');
    }

    public function sanitize_settings($input) {
        $old = get_option(self::OPTION_KEY, array());
        $api_key = sanitize_text_field($input['tv_api_key'] ?? ($old['tv_api_key'] ?? ''));
        return array(
            'school_name' => sanitize_text_field($input['school_name'] ?? ($old['school_name'] ?? '')),
            'logo_url' => esc_url_raw($input['logo_url'] ?? ($old['logo_url'] ?? '')),
            'api_poll_seconds' => max(5, min(300, absint($input['api_poll_seconds'] ?? 15))),
            'tv_api_key' => $api_key ?: wp_generate_password(48, false, false),
        );
    }

    public function text_field($args) {
        $settings = get_option(self::OPTION_KEY, array());
        $key = $args['key'];
        printf('<input class="regular-text" name="%1$s[%2$s]" type="%3$s" value="%4$s" />', esc_attr(self::OPTION_KEY), esc_attr($key), esc_attr($args['type']), esc_attr($settings[$key] ?? ''));
    }

    public function logo_field() {
        $settings = get_option(self::OPTION_KEY, array());
        $url = esc_url($settings['logo_url'] ?? '');
        echo '<input id="driveflow-logo-url" class="regular-text" name="' . esc_attr(self::OPTION_KEY) . '[logo_url]" type="url" value="' . esc_attr($url) . '" />';
        echo ' <button type="button" class="button" id="driveflow-upload-logo">Select logo</button>';
        echo '<p><img id="driveflow-logo-preview" src="' . $url . '" alt="" style="max-width:180px;max-height:120px;margin-top:12px;' . ($url ? '' : 'display:none;') . '" /></p>';
    }

    public function api_key_field() {
        $settings = get_option(self::OPTION_KEY, array());
        echo '<input class="regular-text code" name="' . esc_attr(self::OPTION_KEY) . '[tv_api_key]" type="text" value="' . esc_attr($settings['tv_api_key'] ?? '') . '" autocomplete="off" />';
        echo '<p class="description">The key is sent to the protected TV endpoint. Regenerate it if the TV page URL or browser session is exposed.</p>';
    }

    public function admin_assets($hook) {
        if ('toplevel_page_driveflow-pro' !== $hook) return;
        wp_enqueue_media();
        wp_enqueue_script('driveflow-admin', DRIVEFLOW_PRO_URL . 'assets/admin.js', array('jquery'), DRIVEFLOW_PRO_VERSION, true);
    }

    public function frontend_assets() {
        wp_enqueue_style('driveflow-pro-font', 'https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;600;700;800&display=swap', array(), null);
        wp_enqueue_style('driveflow-pro', DRIVEFLOW_PRO_URL . 'assets/frontend.css', array(), DRIVEFLOW_PRO_VERSION);
        wp_enqueue_script('driveflow-pro', DRIVEFLOW_PRO_URL . 'assets/frontend.js', array(), DRIVEFLOW_PRO_VERSION, true);
        $settings = get_option(self::OPTION_KEY, array());
        wp_localize_script('driveflow-pro', 'DriveFlowPro', array(
            'root' => esc_url_raw(rest_url(self::REST_NAMESPACE)),
            'nonce' => wp_create_nonce('wp_rest'),
            'pollSeconds' => max(5, absint($settings['api_poll_seconds'] ?? 15)),
        ));
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $settings = get_option(self::OPTION_KEY, array());
        echo '<div class="wrap driveflow-admin"><h1>DriveFlow Pro</h1><p>Configure branding and lobby board behavior.</p><form method="post" action="options.php">';
        settings_fields('driveflow_pro_settings_group');
        do_settings_sections('driveflow-pro');
        submit_button('Save configuration');
        echo '</form></div>';
    }

    private function branding() {
        $settings = get_option(self::OPTION_KEY, array());
        return array('name' => sanitize_text_field($settings['school_name'] ?? get_bloginfo('name')), 'logo' => esc_url($settings['logo_url'] ?? ''));
    }

    public function instructor_form() {
        $brand = $this->branding();
        ob_start();
        include DRIVEFLOW_PRO_DIR . 'templates/instructor-form.php';
        return ob_get_clean();
    }

    public function tv_board() {
        $brand = $this->branding();
        $settings = get_option(self::OPTION_KEY, array());
        wp_add_inline_script('driveflow-pro', 'window.DriveFlowPro = Object.assign(window.DriveFlowPro || {}, ' . wp_json_encode(array(
            'tvApiUrl' => esc_url_raw(rest_url(self::REST_NAMESPACE . '/tv-sessions')),
            'tvApiKey' => sanitize_text_field($settings['tv_api_key'] ?? ''),
        )) . ');', 'after');
        ob_start();
        include DRIVEFLOW_PRO_DIR . 'templates/tv-board.php';
        return ob_get_clean();
    }

    public function register_routes() {
        register_rest_route(self::REST_NAMESPACE, '/sessions', array(
            array('methods' => WP_REST_Server::READABLE, 'callback' => array($this, 'get_sessions'), 'permission_callback' => array($this, 'can_write')),
            array('methods' => WP_REST_Server::CREATABLE, 'callback' => array($this, 'create_session'), 'permission_callback' => array($this, 'can_write')),
        ));
        register_rest_route(self::REST_NAMESPACE, '/tv-sessions', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_tv_sessions'),
            'permission_callback' => array($this, 'can_read_tv'),
        ));
        register_rest_route(self::REST_NAMESPACE, '/sessions/(?P<id>\d+)', array(
            array('methods' => WP_REST_Server::EDITABLE, 'callback' => array($this, 'update_session'), 'permission_callback' => array($this, 'can_write')),
            array('methods' => WP_REST_Server::DELETABLE, 'callback' => array($this, 'delete_session'), 'permission_callback' => array($this, 'can_delete')),
        ));
    }

    public function can_write($request) { return is_user_logged_in() && current_user_can('edit_posts') && wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest'); }
    public function can_delete($request) { return current_user_can('manage_options') && wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest'); }

    public function can_read_tv($request) {
        $settings = get_option(self::OPTION_KEY, array());
        $client_key = (string) $request->get_header('X-DriveFlow-API-Key');
        $server_key = (string) ($settings['tv_api_key'] ?? '');
        return $server_key && $client_key && hash_equals($server_key, $client_key)
            ? true
            : new WP_Error('rest_forbidden', 'Invalid TV API key.', array('status' => 403));
    }

    private function table() { global $wpdb; return $wpdb->prefix . 'driveflow_sessions'; }
    private function clean_session($params, $existing = array()) {
        $start = sanitize_text_field($params['scheduled_start'] ?? ($existing['scheduled_start'] ?? current_time('mysql')));
        $end = sanitize_text_field($params['scheduled_end'] ?? ($existing['scheduled_end'] ?? $start));
        $status = sanitize_key($params['status'] ?? ($existing['status'] ?? 'upcoming'));
        if (!in_array($status, array('upcoming', 'active', 'completed', 'cancelled'), true)) $status = 'upcoming';
        $form_data = $params['form_data'] ?? ($existing['form_data'] ?? array());
        if (is_string($form_data)) $form_data = json_decode(wp_unslash($form_data), true);
        $signature = sanitize_textarea_field($params['signature'] ?? ($existing['signature'] ?? ''));
        $selfie = sanitize_textarea_field($params['selfie'] ?? ($existing['selfie'] ?? ''));
        if (strlen($signature) > 2000000) $signature = '';
        if (strlen($selfie) > 5000000) $selfie = '';
        return array(
            'student_name' => sanitize_text_field($params['student_name'] ?? ($existing['student_name'] ?? '')),
            'instructor_name' => sanitize_text_field($params['instructor_name'] ?? ($existing['instructor_name'] ?? '')),
            'session_number' => max(1, absint($params['session_number'] ?? ($existing['session_number'] ?? 1))),
            'lesson_topic' => sanitize_text_field($params['lesson_topic'] ?? ($existing['lesson_topic'] ?? '')),
            'scheduled_start' => preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $start) ? $start : current_time('mysql'),
            'scheduled_end' => preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $end) ? $end : current_time('mysql'),
            'status' => $status,
            'form_data' => wp_json_encode(is_array($form_data) ? $form_data : array()),
            'signature' => $signature,
            'selfie' => $selfie,
        );
    }

    public function get_sessions($request) {
        global $wpdb;
        $limit = min(100, max(1, absint($request->get_param('limit') ?: 50)));
        $status = sanitize_key($request->get_param('status'));
        $where = $status ? $wpdb->prepare(' WHERE status = %s', $status) : '';
        $rows = $wpdb->get_results("SELECT id, student_name, instructor_name, session_number, lesson_topic, scheduled_start, scheduled_end, status, form_data, created_at, updated_at FROM {$this->table()}{$where} ORDER BY scheduled_start ASC LIMIT {$limit}", ARRAY_A);
        foreach ($rows as &$row) $row['form_data'] = json_decode($row['form_data'] ?: '{}', true);
        return rest_ensure_response($rows);
    }

    public function get_tv_sessions($request) {
        global $wpdb;
        $limit = min(50, max(1, absint($request->get_param('limit') ?: 25)));
        $rows = $wpdb->get_results("SELECT id, student_name, instructor_name, session_number, lesson_topic, scheduled_start, scheduled_end, status FROM {$this->table()} WHERE status IN ('upcoming', 'active') ORDER BY scheduled_start ASC LIMIT {$limit}", ARRAY_A);
        return rest_ensure_response($rows);
    }

    public function create_session($request) {
        global $wpdb;
        $data = $this->clean_session($request->get_json_params() ?: array());
        if (!$data['student_name']) return new WP_Error('missing_student', 'Student name is required.', array('status' => 400));
        $now = current_time('mysql');
        $data['created_by'] = get_current_user_id(); $data['created_at'] = $now; $data['updated_at'] = $now;
        $formats = array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s');
        $wpdb->insert($this->table(), $data, $formats);
        if (!$wpdb->insert_id) return new WP_Error('db_insert_failed', 'Session could not be saved.', array('status' => 500));
        return new WP_REST_Response(array('id' => (int) $wpdb->insert_id), 201);
    }

    public function update_session($request) {
        global $wpdb;
        $id = absint($request['id']);
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id = %d", $id), ARRAY_A);
        if (!$existing) return new WP_Error('not_found', 'Session not found.', array('status' => 404));
        $data = $this->clean_session($request->get_json_params() ?: array(), $existing); $data['updated_at'] = current_time('mysql');
        $wpdb->update($this->table(), $data, array('id' => $id), array('%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s'), array('%d'));
        return rest_ensure_response(array('id' => $id, 'updated' => true));
    }

    public function delete_session($request) {
        global $wpdb; $id = absint($request['id']);
        $deleted = $wpdb->delete($this->table(), array('id' => $id), array('%d'));
        return $deleted ? rest_ensure_response(array('deleted' => true)) : new WP_Error('not_found', 'Session not found.', array('status' => 404));
    }
}

register_activation_hook(DRIVEFLOW_PRO_FILE, array('DriveFlow_Pro', 'activate'));
add_action('plugins_loaded', array('DriveFlow_Pro', 'boot'));
